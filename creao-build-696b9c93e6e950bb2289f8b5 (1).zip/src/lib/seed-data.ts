/**
 * Dados de exemplo para popular o sistema CL Digital Box
 *
 * Este arquivo contém dados realistas para demonstração do sistema
 */

import { ClientORM, ClientClientSegment, ClientStatus, type ClientModel } from "@/components/data/orm/orm_client";
import { DemandORM, DemandDemandType, DemandStatus, DemandPriority, type DemandModel } from "@/components/data/orm/orm_demand";
import { DocumentORM, DocumentDocumentType, DocumentStatus, type DocumentModel } from "@/components/data/orm/orm_document";

/**
 * Dados de exemplo de clientes
 */
const SAMPLE_CLIENTS: Partial<ClientModel>[] = [
	{
		full_name: "Maria da Silva Santos",
		cpf_cnpj: "123.456.789-00",
		birth_date: "1985-05-15",
		client_segment: ClientClientSegment.Individual,
		status: ClientStatus.Active,
		contact_info: {
			email: "maria.santos@email.com",
			phone_primary: "(31) 98765-4321",
			phone_secondary: "(31) 3456-7890"
		},
		address_info: {
			street: "Rua das Flores",
			number: "123",
			neighborhood: "Centro",
			city: "Santa Bárbara",
			state: "MG",
			zip_code: "35960-000"
		}
	},
	{
		full_name: "João Carlos Oliveira",
		cpf_cnpj: "987.654.321-00",
		birth_date: "1978-11-20",
		client_segment: ClientClientSegment.Individual,
		status: ClientStatus.Active,
		contact_info: {
			email: "joao.oliveira@email.com",
			phone_primary: "(31) 99876-5432"
		},
		address_info: {
			street: "Avenida Principal",
			number: "456",
			neighborhood: "Bela Vista",
			city: "Belo Horizonte",
			state: "MG",
			zip_code: "30100-000"
		}
	},
	{
		full_name: "Ana Paula Ferreira",
		cpf_cnpj: "456.789.123-00",
		birth_date: "1990-03-25",
		client_segment: ClientClientSegment.Individual,
		status: ClientStatus.Active,
		contact_info: {
			email: "ana.ferreira@email.com",
			phone_primary: "(31) 97654-3210",
			phone_secondary: "(31) 3234-5678"
		},
		address_info: {
			street: "Rua do Comércio",
			number: "789",
			complement: "Apt 201",
			neighborhood: "São João",
			city: "Santa Bárbara",
			state: "MG",
			zip_code: "35960-000"
		}
	},
	{
		full_name: "Carlos Eduardo Souza",
		cpf_cnpj: "789.123.456-00",
		birth_date: "1982-07-10",
		client_segment: ClientClientSegment.Individual,
		status: ClientStatus.Active,
		contact_info: {
			email: "carlos.souza@email.com",
			phone_primary: "(31) 96543-2109"
		},
		address_info: {
			street: "Rua da Liberdade",
			number: "321",
			neighborhood: "Industrial",
			city: "Contagem",
			state: "MG",
			zip_code: "32000-000"
		}
	},
	{
		full_name: "Transportadora Santa Bárbara LTDA",
		cpf_cnpj: "12.345.678/0001-90",
		client_segment: ClientClientSegment.Corporate,
		status: ClientStatus.Active,
		contact_info: {
			email: "contato@transportadorasb.com.br",
			phone_primary: "(31) 3333-4444",
			phone_secondary: "(31) 98888-9999"
		},
		address_info: {
			street: "Rodovia BR-381",
			number: "1000",
			neighborhood: "Distrito Industrial",
			city: "Santa Bárbara",
			state: "MG",
			zip_code: "35960-000"
		}
	}
];

/**
 * Tipos de demandas para cada cliente
 */
interface SampleDemand extends Partial<DemandModel> {
	clientIndex: number;
}

const SAMPLE_DEMANDS: SampleDemand[] = [
	{
		clientIndex: 0, // Maria da Silva Santos
		demand_number: "2024/IPI/001",
		demand_type: DemandDemandType.Tax,
		status: DemandStatus.InProgress,
		priority: DemandPriority.High,
		description: "Solicitação de isenção de IPI e ICMS para aquisição de veículo adaptado - Pessoa com Deficiência (PCD). Laudo médico aprovado, aguardando análise da documentação complementar pela Receita Federal."
	},
	{
		clientIndex: 0, // Maria da Silva Santos
		demand_number: "2024/DOC/045",
		demand_type: DemandDemandType.Other,
		status: DemandStatus.Waiting,
		priority: DemandPriority.Medium,
		description: "Aguardando recebimento de comprovante de residência atualizado para complementar processo de isenção fiscal."
	},
	{
		clientIndex: 1, // João Carlos Oliveira
		demand_number: "2024/INSS/012",
		demand_type: DemandDemandType.SocialSecurity,
		status: DemandStatus.New,
		priority: DemandPriority.Critical,
		description: "Processo de aposentadoria por tempo de contribuição. Cliente possui 35 anos de contribuição comprovados. Necessário agendar perícia do INSS."
	},
	{
		clientIndex: 2, // Ana Paula Ferreira
		demand_number: "2024/TAX/078",
		demand_type: DemandDemandType.Tax,
		status: DemandStatus.InProgress,
		priority: DemandPriority.High,
		description: "Isenção IPI/ICMS para taxista. CNH categoria B aprovada, documentação profissional em análise. Alvará de taxista válido até 2026."
	},
	{
		clientIndex: 3, // Carlos Eduardo Souza
		demand_number: "2024/RFB/033",
		demand_type: DemandDemandType.Tax,
		status: DemandStatus.Suspended,
		priority: DemandPriority.Low,
		description: "Processo de parcelamento de débitos junto à Receita Federal suspenso temporariamente a pedido do cliente para reorganização financeira."
	},
	{
		clientIndex: 3, // Carlos Eduardo Souza
		demand_number: "2024/RFB/034",
		demand_type: DemandDemandType.Tax,
		status: DemandStatus.Concluded,
		priority: DemandPriority.Medium,
		description: "Intimação fiscal - RFB. Processo de defesa administrativa concluído com êxito. Notificação fiscal cancelada pela autoridade competente."
	},
	{
		clientIndex: 4, // Transportadora
		demand_number: "2024/EMP/019",
		demand_type: DemandDemandType.Administrative,
		status: DemandStatus.InProgress,
		priority: DemandPriority.High,
		description: "Aferição de obra para ampliação de galpão industrial. Documentação técnica aprovada, aguardando vistoria do corpo de bombeiros."
	}
];

/**
 * Documentos de exemplo vinculados às demandas
 */
interface SampleDocument extends Partial<DocumentModel> {
	demandIndex: number;
	document_name: string;
	file_path: string;
	notes?: string;
}

const SAMPLE_DOCUMENTS: SampleDocument[] = [
	{
		demandIndex: 0,
		document_name: "Laudo Médico PCD - Maria Santos",
		document_type: DocumentDocumentType.Other,
		status: DocumentStatus.Valid,
		file_path: "/documentos/maria-santos/laudo-medico-pcd.pdf",
		notes: "Laudo emitido pelo Dr. Roberto Silva - CRM/MG 12345. Validade: 12 meses a partir de 10/01/2024."
	},
	{
		demandIndex: 0,
		document_name: "CPF e RG - Maria Santos",
		document_type: DocumentDocumentType.Identification,
		status: DocumentStatus.Valid,
		file_path: "/documentos/maria-santos/cpf-rg.pdf",
		notes: "Documentos pessoais digitalizados em alta resolução."
	},
	{
		demandIndex: 0,
		document_name: "Comprovante de Residência",
		document_type: DocumentDocumentType.AddressProof,
		status: DocumentStatus.Pending,
		file_path: "/documentos/maria-santos/comprovante-residencia.pdf",
		notes: "Conta de luz de dezembro/2024. Aguardando recebimento de documento mais recente."
	},
	{
		demandIndex: 2,
		document_name: "CNIS - João Oliveira",
		document_type: DocumentDocumentType.Other,
		status: DocumentStatus.Valid,
		file_path: "/documentos/joao-oliveira/cnis.pdf",
		notes: "Cadastro Nacional de Informações Sociais atualizado em 05/12/2024. Tempo de contribuição: 35 anos e 4 meses."
	},
	{
		demandIndex: 2,
		document_name: "Carteira de Trabalho Digital",
		document_type: DocumentDocumentType.Other,
		status: DocumentStatus.Valid,
		file_path: "/documentos/joao-oliveira/ctps-digital.pdf",
		notes: "Carteira de trabalho digital com todos os registros de vínculos empregatícios."
	},
	{
		demandIndex: 3,
		document_name: "CNH Categoria B - Ana Ferreira",
		document_type: DocumentDocumentType.Identification,
		status: DocumentStatus.Valid,
		file_path: "/documentos/ana-ferreira/cnh.pdf",
		notes: "CNH válida até 2028. Categoria B aprovada para isenção de taxista."
	},
	{
		demandIndex: 3,
		document_name: "Alvará de Taxista",
		document_type: DocumentDocumentType.Other,
		status: DocumentStatus.Valid,
		file_path: "/documentos/ana-ferreira/alvara-taxista.pdf",
		notes: "Alvará municipal válido até março/2026. Renovação programada."
	},
	{
		demandIndex: 6,
		document_name: "Projeto de Ampliação - Transportadora",
		document_type: DocumentDocumentType.Other,
		status: DocumentStatus.Pending,
		file_path: "/documentos/transportadora/projeto-ampliacao.pdf",
		notes: "Projeto arquitetônico aprovado pela prefeitura. Aguardando vistoria técnica."
	}
];

/**
 * Função para popular o banco de dados com dados de exemplo
 */
export async function seedDatabase(): Promise<{
	success: boolean;
	message: string;
	stats?: {
		clients: number;
		demands: number;
		documents: number;
	};
}> {
	try {
		const clientORM = ClientORM.getInstance();
		const demandORM = DemandORM.getInstance();
		const documentORM = DocumentORM.getInstance();

		// Verificar se já existem dados
		const existingClients = await clientORM.getAllClient();
		if (existingClients.length > 0) {
			return {
				success: false,
				message: "O sistema já possui dados cadastrados. Para popular novamente, exclua todos os dados primeiro."
			};
		}

		// Criar clientes (insertClient espera array de ClientModel)
		const createdClients = await clientORM.insertClient(SAMPLE_CLIENTS as ClientModel[]);

		// Criar demandas
		const demandsToInsert: Partial<DemandModel>[] = SAMPLE_DEMANDS.map((demandData) => {
			const client = createdClients[demandData.clientIndex];
			const { clientIndex, ...demandFields } = demandData;
			return {
				...demandFields,
				client_id: client.id
			};
		});
		const createdDemands = await demandORM.insertDemand(demandsToInsert as DemandModel[]);

		// Criar documentos
		const documentsToInsert: Partial<DocumentModel>[] = SAMPLE_DOCUMENTS.map((docData) => {
			const demand = createdDemands[docData.demandIndex];
			const client = createdClients[SAMPLE_DEMANDS[docData.demandIndex].clientIndex];
			const { demandIndex, document_name, file_path, notes, ...docFields } = docData;

			return {
				...docFields,
				client_id: client.id,
				demand_id: demand.id,
				file_info: {
					file_name: document_name,
					file_size: 1024000,
					mime_type: "application/pdf",
					file_url: file_path
				},
				metadata: {
					notes: notes || null
				}
			};
		});
		const createdDocuments = await documentORM.insertDocument(documentsToInsert as DocumentModel[]);

		return {
			success: true,
			message: `Dados de exemplo criados com sucesso!
${createdClients.length} clientes, ${createdDemands.length} demandas e ${createdDocuments.length} documentos.`,
			stats: {
				clients: createdClients.length,
				demands: createdDemands.length,
				documents: createdDocuments.length
			}
		};

	} catch (error) {
		console.error("Erro ao popular banco de dados:", error);
		return {
			success: false,
			message: `Erro ao criar dados de exemplo: ${error instanceof Error ? error.message : 'Erro desconhecido'}`
		};
	}
}

/**
 * Função para limpar todos os dados do sistema
 */
export async function clearDatabase(): Promise<{
	success: boolean;
	message: string;
}> {
	try {
		const clientORM = ClientORM.getInstance();
		const demandORM = DemandORM.getInstance();
		const documentORM = DocumentORM.getInstance();

		// Obter todos os IDs
		const clients = await clientORM.getAllClient();
		const demands = await demandORM.getAllDemand();
		const documents = await documentORM.getAllDocument();

		// Excluir documentos primeiro (dependências)
		for (const doc of documents) {
			await documentORM.deleteDocumentById(doc.id);
		}

		// Excluir demandas
		for (const demand of demands) {
			await demandORM.deleteDemandById(demand.id);
		}

		// Excluir clientes
		for (const client of clients) {
			await clientORM.deleteClientById(client.id);
		}

		return {
			success: true,
			message: `Todos os dados foram removidos com sucesso!
${clients.length} clientes, ${demands.length} demandas e ${documents.length} documentos excluídos.`
		};

	} catch (error) {
		console.error("Erro ao limpar banco de dados:", error);
		return {
			success: false,
			message: `Erro ao limpar dados: ${error instanceof Error ? error.message : 'Erro desconhecido'}`
		};
	}
}
