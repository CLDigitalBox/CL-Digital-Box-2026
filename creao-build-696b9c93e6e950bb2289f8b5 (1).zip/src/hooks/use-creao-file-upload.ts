import { useMutation, type UseMutationResult } from '@tanstack/react-query';
import { postMainOfficialApiPresignS3Upload } from '@/sdk/api-clients/CreaoFileUpload';

export interface UploadFileInput {
  file: File;
  onProgress?: (progress: number) => void;
}

export interface UploadFileResponse {
  fileUrl: string;
  fileKey: string;
  fileName: string;
  contentType: string;
}

/**
 * Hook for uploading files to Creao platform storage via S3 presigned URLs.
 *
 * This hook handles the two-step upload process:
 * 1. Requests a presigned URL from the Creao API
 * 2. Uploads the file directly to S3 using the presigned URL
 *
 * @example
 * ```tsx
 * const uploadMutation = useCreaoFileUploadMutation();
 *
 * const handleUpload = async (file: File) => {
 *   try {
 *     const result = await uploadMutation.mutateAsync({
 *       file,
 *       onProgress: (progress) => console.log(`Upload progress: ${progress}%`)
 *     });
 *     console.log('File uploaded:', result.fileUrl);
 *   } catch (error) {
 *     console.error('Upload failed:', error);
 *   }
 * };
 * ```
 */
export function useCreaoFileUploadMutation(): UseMutationResult<
  UploadFileResponse,
  Error,
  UploadFileInput
> {
  return useMutation({
    mutationFn: async (input: UploadFileInput): Promise<UploadFileResponse> => {
      // Validate file input
      if (!input.file || !(input.file instanceof File)) {
        throw new Error('Valid File object is required');
      }

      const { file, onProgress } = input;

      // Step 1: Get presigned URL from Creao API
      const presignResponse = await postMainOfficialApiPresignS3Upload({
        body: {
          fileName: file.name,
          contentType: file.type || 'application/octet-stream',
        },
        headers: {
          'X-CREAO-API-NAME': 'CreaoFileUpload',
          'X-CREAO-API-PATH': '/main/official-api/presign-s3-upload',
          'X-CREAO-API-ID': '68b68b97ac476c8df7efbeaf',
        },
      });

      // Handle API errors
      if (presignResponse.error) {
        const errorMessage = presignResponse.error.message || 'Failed to get presigned URL';
        throw new Error(errorMessage);
      }

      // Validate presigned URL response
      if (!presignResponse.data) {
        throw new Error('No response data received from presign API');
      }

      const { presignedUrl, realFileUrl, fileKey } = presignResponse.data;

      if (!presignedUrl) {
        throw new Error('No presigned URL returned from API');
      }

      if (!realFileUrl) {
        throw new Error('No file URL returned from API');
      }

      // Step 2: Upload file to S3 using presigned URL
      const uploadResponse = await new Promise<Response>((resolve, reject) => {
        const xhr = new XMLHttpRequest();

        // Track upload progress
        if (onProgress) {
          xhr.upload.addEventListener('progress', (event) => {
            if (event.lengthComputable) {
              const percentComplete = Math.round((event.loaded / event.total) * 100);
              onProgress(percentComplete);
            }
          });
        }

        // Handle completion
        xhr.addEventListener('load', () => {
          if (xhr.status >= 200 && xhr.status < 300) {
            resolve(new Response(xhr.response, {
              status: xhr.status,
              statusText: xhr.statusText,
            }));
          } else {
            reject(new Error(`S3 upload failed with status ${xhr.status}: ${xhr.statusText}`));
          }
        });

        // Handle errors
        xhr.addEventListener('error', () => {
          reject(new Error('Network error during file upload'));
        });

        xhr.addEventListener('abort', () => {
          reject(new Error('File upload was aborted'));
        });

        // Initiate upload
        xhr.open('PUT', presignedUrl);
        xhr.setRequestHeader('Content-Type', file.type || 'application/octet-stream');
        xhr.send(file);
      });

      // Verify successful upload
      if (!uploadResponse.ok) {
        throw new Error(`File upload to S3 failed with status ${uploadResponse.status}`);
      }

      // Return upload result
      return {
        fileUrl: realFileUrl,
        fileKey: fileKey || '',
        fileName: file.name,
        contentType: file.type || 'application/octet-stream',
      };
    },
  });
}
