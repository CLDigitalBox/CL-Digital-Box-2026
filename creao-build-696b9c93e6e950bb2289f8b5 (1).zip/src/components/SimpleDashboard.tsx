import React from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ClientList } from "@/components/ClientList";
import { DemandList } from "@/components/DemandList";
import { DocumentList } from "@/components/DocumentList";
import { WorkflowManager } from "@/components/WorkflowManager";
import { InstallmentManager } from "@/components/InstallmentManager";
import { InteractionManager } from "@/components/InteractionManager";
import { ReportGenerator } from "@/components/ReportGenerator";
import { DigitalSignature } from "@/components/DigitalSignature";
import { NotificationCenter } from "@/components/NotificationCenter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
	Users,
	Building2,
	FileText,
	File,
	GitBranch,
	DollarSign,
	MessageSquare,
	FileBarChart,
	FileSignature,
	Bell,
	Database,
	Trash2,
	AlertCircle,
	CheckCircle2
} from "lucide-react";
import { ClientORM } from "@/components/data/orm/orm_client";
import { DemandORM, DemandStatus } from "@/components/data/orm/orm_demand";
import { DocumentORM } from "@/components/data/orm/orm_document";
import { InteractionORM } from "@/components/data/orm/orm_interaction";
import { NotificationORM } from "@/components/data/orm/orm_notification";
import { seedDatabase, clearDatabase } from "@/lib/seed-data";
import clLogo from "@/assets/cl-logo.svg";

export function SimpleDashboard() {
	const [stats, setStats] = React.useState({
		clients: 0,
		demands: 0,
		documents: 0,
		interactions: 0,
		notifications: 0,
		demandsActive: 0,
		demandsPending: 0,
		demandsCompleted: 0,
		loading: true,
	});
	const [seedMessage, setSeedMessage] = React.useState<{ type: 'success' | 'error'; message: string } | null>(null);
	const [seedLoading, setSeedLoading] = React.useState(false);

	const clientORM = React.useMemo(() => ClientORM.getInstance(), []);
	const demandORM = React.useMemo(() => DemandORM.getInstance(), []);
	const documentORM = React.useMemo(() => DocumentORM.getInstance(), []);
	const interactionORM = React.useMemo(() => InteractionORM.getInstance(), []);
	const notificationORM = React.useMemo(() => NotificationORM.getInstance(), []);

	React.useEffect(() => {
		loadStats();
	}, []);

	const loadStats = async () => {
		try {
			const [clients, demands, documents, interactions, notifications] = await Promise.all([
				clientORM.getAllClient(),
				demandORM.getAllDemand(),
				documentORM.getAllDocument(),
				interactionORM.getAllInteraction(),
				notificationORM.getAllNotification(),
			]);

			const demandsActive = demands.filter(d => d.status === DemandStatus.InProgress).length;
			const demandsPending = demands.filter(d => d.status === DemandStatus.New || d.status === DemandStatus.Waiting).length;
			const demandsCompleted = demands.filter(d => d.status === DemandStatus.Concluded).length;

			setStats({
				clients: clients.length,
				demands: demands.length,
				documents: documents.length,
				interactions: interactions.length,
				notifications: notifications.length,
				demandsActive,
				demandsPending,
				demandsCompleted,
				loading: false,
			});
		} catch (error) {
			console.error("Error loading stats:", error);
			setStats((prev) => ({ ...prev, loading: false }));
		}
	};

	const handleSeedDatabase = async () => {
		setSeedLoading(true);
		setSeedMessage(null);
		try {
			const result = await seedDatabase();
			setSeedMessage({
				type: result.success ? 'success' : 'error',
				message: result.message
			});
			if (result.success) {
				await loadStats();
			}
		} catch (error) {
			setSeedMessage({
				type: 'error',
				message: `Erro ao popular banco de dados: ${error instanceof Error ? error.message : 'Erro desconhecido'}`
			});
		} finally {
			setSeedLoading(false);
		}
	};

	const handleClearDatabase = async () => {
		if (!confirm('Tem certeza que deseja excluir TODOS os dados do sistema? Esta ação não pode ser desfeita!')) {
			return;
		}
		setSeedLoading(true);
		setSeedMessage(null);
		try {
			const result = await clearDatabase();
			setSeedMessage({
				type: result.success ? 'success' : 'error',
				message: result.message
			});
			if (result.success) {
				await loadStats();
			}
		} catch (error) {
			setSeedMessage({
				type: 'error',
				message: `Erro ao limpar banco de dados: ${error instanceof Error ? error.message : 'Erro desconhecido'}`
			});
		} finally {
			setSeedLoading(false);
		}
	};

	return (
		<div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
			<header className="bg-white border-b shadow-sm sticky top-0 z-50">
				<div className="container mx-auto px-4 py-4">
					<div className="flex items-center gap-4">
						<img
							src={clLogo}
							alt="CL Assessoria Logo"
							className="w-14 h-14 object-contain"
						/>
						<div className="flex-1">
							<h1 className="text-2xl font-bold text-gray-900">
								CL Assessoria e Consultoria Digital
							</h1>
							<p className="text-sm text-gray-600">
								CL Digittal Box - Sistema Integrado de Gestão
							</p>
						</div>
						<div className="text-right text-sm text-gray-600">
							<p className="font-medium">Santa Bárbara, MG</p>
							<p className="text-xs">Brasil</p>
						</div>
					</div>
				</div>
			</header>

			<main className="container mx-auto px-4 py-8">
				<Tabs defaultValue="dashboard" className="w-full">
					<TabsList className="grid w-full grid-cols-5 lg:grid-cols-10 h-auto">
						<TabsTrigger value="dashboard" className="gap-2 py-3">
							<Building2 className="h-4 w-4" />
							<span className="hidden md:inline">Dashboard</span>
						</TabsTrigger>
						<TabsTrigger value="clients" className="gap-2 py-3">
							<Users className="h-4 w-4" />
							<span className="hidden md:inline">Clientes</span>
						</TabsTrigger>
						<TabsTrigger value="demands" className="gap-2 py-3">
							<FileText className="h-4 w-4" />
							<span className="hidden md:inline">Demandas</span>
						</TabsTrigger>
						<TabsTrigger value="documents" className="gap-2 py-3">
							<File className="h-4 w-4" />
							<span className="hidden md:inline">Documentos</span>
						</TabsTrigger>
						<TabsTrigger value="workflows" className="gap-2 py-3">
							<GitBranch className="h-4 w-4" />
							<span className="hidden md:inline">Workflows</span>
						</TabsTrigger>
						<TabsTrigger value="installments" className="gap-2 py-3">
							<DollarSign className="h-4 w-4" />
							<span className="hidden md:inline">Parcelamentos</span>
						</TabsTrigger>
						<TabsTrigger value="interactions" className="gap-2 py-3">
							<MessageSquare className="h-4 w-4" />
							<span className="hidden md:inline">Interações</span>
						</TabsTrigger>
						<TabsTrigger value="reports" className="gap-2 py-3">
							<FileBarChart className="h-4 w-4" />
							<span className="hidden md:inline">Relatórios</span>
						</TabsTrigger>
						<TabsTrigger value="signature" className="gap-2 py-3">
							<FileSignature className="h-4 w-4" />
							<span className="hidden md:inline">Assinatura</span>
						</TabsTrigger>
						<TabsTrigger value="notifications" className="gap-2 py-3">
							<Bell className="h-4 w-4" />
							<span className="hidden md:inline">Notificações</span>
						</TabsTrigger>
					</TabsList>

					<TabsContent value="dashboard" className="mt-6">
						<div className="space-y-6">
							<div>
								<h2 className="text-3xl font-bold text-gray-900">Dashboard</h2>
								<p className="text-sm text-gray-600 mt-1">
									Bem-vindo ao sistema CL Digittal Box
								</p>
							</div>

							{seedMessage && (
								<Alert className={seedMessage.type === 'success' ? 'border-green-500 bg-green-50' : 'border-red-500 bg-red-50'}>
									{seedMessage.type === 'success' ? (
										<CheckCircle2 className="h-4 w-4 text-green-600" />
									) : (
										<AlertCircle className="h-4 w-4 text-red-600" />
									)}
									<AlertDescription className={seedMessage.type === 'success' ? 'text-green-800' : 'text-red-800'}>
										{seedMessage.message}
									</AlertDescription>
								</Alert>
							)}

							<div className="grid grid-cols-1 md:grid-cols-3 gap-4">
								<Card>
									<CardHeader className="flex flex-row items-center justify-between pb-2">
										<CardTitle className="text-sm font-medium text-gray-600">
											Total de Clientes
										</CardTitle>
										<Users className="h-4 w-4 text-blue-600" />
									</CardHeader>
									<CardContent>
										<div className="text-2xl font-bold">
											{stats.loading ? "..." : stats.clients}
										</div>
										<p className="text-xs text-gray-500 mt-1">
											Clientes cadastrados
										</p>
									</CardContent>
								</Card>

								<Card>
									<CardHeader className="flex flex-row items-center justify-between pb-2">
										<CardTitle className="text-sm font-medium text-gray-600">
											Total de Demandas
										</CardTitle>
										<FileText className="h-4 w-4 text-purple-600" />
									</CardHeader>
									<CardContent>
										<div className="text-2xl font-bold">
											{stats.loading ? "..." : stats.demands}
										</div>
										<p className="text-xs text-gray-500 mt-1">
											Processos em andamento
										</p>
									</CardContent>
								</Card>

								<Card>
									<CardHeader className="flex flex-row items-center justify-between pb-2">
										<CardTitle className="text-sm font-medium text-gray-600">
											Total de Documentos
										</CardTitle>
										<File className="h-4 w-4 text-green-600" />
									</CardHeader>
									<CardContent>
										<div className="text-2xl font-bold">
											{stats.loading ? "..." : stats.documents}
										</div>
										<p className="text-xs text-gray-500 mt-1">
											Documentos armazenados
										</p>
									</CardContent>
								</Card>
							</div>

							<div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
								<Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
									<CardHeader className="flex flex-row items-center justify-between pb-2">
										<CardTitle className="text-sm font-medium text-blue-700">
											Em Andamento
										</CardTitle>
										<GitBranch className="h-4 w-4 text-blue-600" />
									</CardHeader>
									<CardContent>
										<div className="text-2xl font-bold text-blue-900">
											{stats.loading ? "..." : stats.demandsActive}
										</div>
										<p className="text-xs text-blue-600 mt-1">
											Demandas ativas
										</p>
									</CardContent>
								</Card>

								<Card className="bg-gradient-to-br from-yellow-50 to-yellow-100 border-yellow-200">
									<CardHeader className="flex flex-row items-center justify-between pb-2">
										<CardTitle className="text-sm font-medium text-yellow-700">
											Pendentes
										</CardTitle>
										<AlertCircle className="h-4 w-4 text-yellow-600" />
									</CardHeader>
									<CardContent>
										<div className="text-2xl font-bold text-yellow-900">
											{stats.loading ? "..." : stats.demandsPending}
										</div>
										<p className="text-xs text-yellow-600 mt-1">
											Aguardando início
										</p>
									</CardContent>
								</Card>

								<Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
									<CardHeader className="flex flex-row items-center justify-between pb-2">
										<CardTitle className="text-sm font-medium text-green-700">
											Concluídas
										</CardTitle>
										<CheckCircle2 className="h-4 w-4 text-green-600" />
									</CardHeader>
									<CardContent>
										<div className="text-2xl font-bold text-green-900">
											{stats.loading ? "..." : stats.demandsCompleted}
										</div>
										<p className="text-xs text-green-600 mt-1">
											Processos finalizados
										</p>
									</CardContent>
								</Card>

								<Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
									<CardHeader className="flex flex-row items-center justify-between pb-2">
										<CardTitle className="text-sm font-medium text-purple-700">
											Interações
										</CardTitle>
										<MessageSquare className="h-4 w-4 text-purple-600" />
									</CardHeader>
									<CardContent>
										<div className="text-2xl font-bold text-purple-900">
											{stats.loading ? "..." : stats.interactions}
										</div>
										<p className="text-xs text-purple-600 mt-1">
											Registros de contato
										</p>
									</CardContent>
								</Card>

								<Card className="bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200">
									<CardHeader className="flex flex-row items-center justify-between pb-2">
										<CardTitle className="text-sm font-medium text-orange-700">
											Notificações
										</CardTitle>
										<Bell className="h-4 w-4 text-orange-600" />
									</CardHeader>
									<CardContent>
										<div className="text-2xl font-bold text-orange-900">
											{stats.loading ? "..." : stats.notifications}
										</div>
										<p className="text-xs text-orange-600 mt-1">
											Mensagens enviadas
										</p>
									</CardContent>
								</Card>
							</div>

							<div className="grid grid-cols-1 md:grid-cols-2 gap-4">
								<Card>
									<CardHeader>
										<CardTitle>Sobre o Sistema</CardTitle>
									</CardHeader>
									<CardContent>
										<p className="text-sm text-gray-600">
											O CL Digittal Box é um sistema completo de gestão
											administrativa e jurídica desenvolvido para escritórios de
											consultoria e assessoria.
										</p>
										<div className="mt-4 space-y-2">
											<p className="text-sm font-medium text-gray-700">
												Módulos Disponíveis:
											</p>
											<ul className="text-sm text-gray-600 space-y-1 ml-4">
												<li>• Gestão de Clientes e Demandas</li>
												<li>• Workflows Jurídicos Automáticos</li>
												<li>• Controle de Parcelamentos Fiscais</li>
												<li>• Central de Interações e Triagem IA</li>
												<li>• Geração de Relatórios PDF</li>
												<li>• Assinatura Digital A1</li>
												<li>• Notificações E-mail e WhatsApp</li>
											</ul>
										</div>
									</CardContent>
								</Card>

								<Card>
									<CardHeader>
										<CardTitle>Gerenciar Dados de Exemplo</CardTitle>
									</CardHeader>
									<CardContent>
										<p className="text-sm text-gray-600 mb-4">
											Popule o sistema com dados realistas para testar todas as funcionalidades
											ou limpe todos os dados existentes.
										</p>
										<div className="space-y-3">
											<Button
												onClick={handleSeedDatabase}
												disabled={seedLoading}
												className="w-full gap-2 bg-blue-600 hover:bg-blue-700"
											>
												<Database className="w-4 h-4" />
												{seedLoading ? 'Populando...' : 'Popular com Dados de Exemplo'}
											</Button>
											<Button
												onClick={handleClearDatabase}
												disabled={seedLoading}
												variant="destructive"
												className="w-full gap-2"
											>
												<Trash2 className="w-4 h-4" />
												{seedLoading ? 'Limpando...' : 'Limpar Todos os Dados'}
											</Button>
										</div>
										<div className="mt-4 p-3 bg-blue-50 rounded-lg">
											<p className="text-xs text-blue-800">
												<strong>Dados incluídos:</strong> 5 clientes, 7 demandas e 8 documentos
												com informações realistas de processos jurídicos e administrativos.
											</p>
										</div>
									</CardContent>
								</Card>
							</div>
						</div>
					</TabsContent>

					<TabsContent value="clients" className="mt-6">
						<ClientList />
					</TabsContent>

					<TabsContent value="demands" className="mt-6">
						<DemandList />
					</TabsContent>

					<TabsContent value="documents" className="mt-6">
						<DocumentList />
					</TabsContent>

					<TabsContent value="workflows" className="mt-6">
						<WorkflowManager />
					</TabsContent>

					<TabsContent value="installments" className="mt-6">
						<InstallmentManager />
					</TabsContent>

					<TabsContent value="interactions" className="mt-6">
						<InteractionManager />
					</TabsContent>

					<TabsContent value="reports" className="mt-6">
						<ReportGenerator />
					</TabsContent>

					<TabsContent value="signature" className="mt-6">
						<DigitalSignature />
					</TabsContent>

					<TabsContent value="notifications" className="mt-6">
						<NotificationCenter />
					</TabsContent>
				</Tabs>
			</main>
		</div>
	);
}
