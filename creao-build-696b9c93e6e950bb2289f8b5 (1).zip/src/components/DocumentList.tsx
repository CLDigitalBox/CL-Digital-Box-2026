import React from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Search, FileText, File, Plus, Trash2 } from "lucide-react";
import { DocumentForm } from "@/components/DocumentForm";
import { DocumentORM, DocumentDocumentType, DocumentStatus } from "@/components/data/orm/orm_document";
import type { DocumentModel } from "@/components/data/orm/orm_document";
import { ClientORM } from "@/components/data/orm/orm_client";
import type { ClientModel } from "@/components/data/orm/orm_client";

export function DocumentList() {
	const [showForm, setShowForm] = React.useState(false);
	const [documents, setDocuments] = React.useState<DocumentModel[]>([]);
	const [clients, setClients] = React.useState<Map<string, ClientModel>>(new Map());
	const [loading, setLoading] = React.useState(true);
	const [searchTerm, setSearchTerm] = React.useState("");
	const documentORM = React.useMemo(() => DocumentORM.getInstance(), []);
	const clientORM = React.useMemo(() => ClientORM.getInstance(), []);

	React.useEffect(() => {
		loadData();
	}, []);

	const loadData = async () => {
		try {
			setLoading(true);
			const [documentsData, clientsData] = await Promise.all([
				documentORM.getAllDocument(),
				clientORM.getAllClient(),
			]);

			const clientMap = new Map(clientsData.map((c: ClientModel) => [c.id, c]));
			setClients(clientMap);
			setDocuments(documentsData);
		} catch (error) {
			console.error("Error loading documents:", error);
		} finally {
			setLoading(false);
		}
	};

	const handleDelete = async (id: string) => {
		if (!confirm("Tem certeza que deseja excluir este documento? Esta ação não pode ser desfeita.")) return;
		try {
			await documentORM.deleteDocumentById(id);
			await loadData();
		} catch (error) {
			console.error("Error deleting document:", error);
			alert("Erro ao excluir documento.");
		}
	};

	const filteredDocuments = React.useMemo(() => {
		return documents.filter((doc) => {
			const client = clients.get(doc.client_id);
			const clientName = client?.full_name || "";
			const fileName = doc.file_info.file_name || "";

			return (
				clientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
				fileName.toLowerCase().includes(searchTerm.toLowerCase())
			);
		});
	}, [documents, clients, searchTerm]);

	const getDocumentTypeBadge = (type: DocumentDocumentType) => {
		const labels: Record<number, string> = {
			[DocumentDocumentType.Identification]: "Identificação",
			[DocumentDocumentType.AddressProof]: "Comp. Endereço",
			[DocumentDocumentType.Contract]: "Contrato",
			[DocumentDocumentType.LegalProcess]: "Processo Legal",
			[DocumentDocumentType.Evidence]: "Prova",
			[DocumentDocumentType.Invoice]: "Nota Fiscal",
			[DocumentDocumentType.Other]: "Outro",
		};
		const label = labels[type] || "Desconhecido";
		return <Badge className="bg-blue-100 text-blue-800">{label}</Badge>;
	};

	const getStatusBadge = (status: DocumentStatus) => {
		const variants: Record<number, { label: string; className: string }> = {
			[DocumentStatus.Pending]: { label: "Pendente", className: "bg-yellow-100 text-yellow-800" },
			[DocumentStatus.Valid]: { label: "Válido", className: "bg-green-100 text-green-800" },
			[DocumentStatus.Rejected]: { label: "Rejeitado", className: "bg-red-100 text-red-800" },
			[DocumentStatus.Expired]: { label: "Expirado", className: "bg-gray-100 text-gray-800" },
			[DocumentStatus.Archived]: { label: "Arquivado", className: "bg-slate-100 text-slate-800" },
		};
		const variant = variants[status] || { label: "Desconhecido", className: "bg-gray-100 text-gray-800" };
		return <Badge className={variant.className}>{variant.label}</Badge>;
	};

	const formatFileSize = (bytes: number): string => {
		if (bytes < 1024) return `${bytes} B`;
		if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
		return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
	};

	if (showForm) {
		return (
			<DocumentForm
				onClose={() => {
					setShowForm(false);
					loadData();
				}}
			/>
		);
	}

	return (
		<div className="space-y-6">
			<div className="flex items-center justify-between">
				<div>
					<h2 className="text-3xl font-bold text-gray-900">Documentos</h2>
					<p className="text-sm text-gray-600 mt-1">
						Gerenciar documentos e arquivos
					</p>
				</div>
				<Button onClick={() => setShowForm(true)} className="gap-2">
					<Plus className="w-4 h-4" />
					Novo Documento
				</Button>
			</div>

			<Card>
				<CardHeader>
					<div className="flex items-center gap-4">
						<div className="flex-1 relative">
							<Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
							<Input
								placeholder="Buscar por cliente ou nome do documento..."
								value={searchTerm}
								onChange={(e) => setSearchTerm(e.target.value)}
								className="pl-10"
							/>
						</div>
					</div>
				</CardHeader>
				<CardContent>
					{loading ? (
						<div className="text-center py-8 text-gray-500">
							Carregando documentos...
						</div>
					) : filteredDocuments.length === 0 ? (
						<div className="text-center py-8">
							<File className="w-12 h-12 mx-auto mb-3 text-gray-300" />
							<p className="text-gray-500">
								{searchTerm
									? "Nenhum documento encontrado"
									: "Nenhum documento cadastrado"}
							</p>
							{!searchTerm && (
								<Button
									onClick={() => setShowForm(true)}
									variant="outline"
									className="mt-4 gap-2"
								>
									<Plus className="w-4 h-4" />
									Cadastrar Primeiro Documento
								</Button>
							)}
						</div>
					) : (
						<div className="space-y-4">
							{filteredDocuments.map((doc) => {
								const client = clients.get(doc.client_id);
								return (
									<Card
										key={doc.id}
										className="hover:shadow-md transition-shadow"
									>
										<CardContent className="p-4">
											<div className="flex items-start justify-between gap-4">
												<div className="flex items-start gap-3">
													<FileText className="w-5 h-5 text-blue-600 mt-1" />
													<div className="flex-1 space-y-1">
														<div className="flex items-center gap-2">
															<h3 className="font-semibold">{doc.file_info.file_name}</h3>
															{getDocumentTypeBadge(doc.document_type)}
															{getStatusBadge(doc.status)}
														</div>
														<p className="text-sm text-gray-600">
															Cliente: {client?.full_name || "Não vinculado"}
														</p>
														<div className="flex items-center gap-4 text-xs text-gray-500">
															<span>Tamanho: {formatFileSize(doc.file_info.file_size)}</span>
															<span>Tipo: {doc.file_info.mime_type}</span>
															{doc.metadata?.issue_date && (
																<span>
																	Emitido: {new Date(doc.metadata.issue_date).toLocaleDateString('pt-BR')}
																</span>
															)}
														</div>
													</div>
												</div>
												<Button
													variant="ghost"
													size="sm"
													onClick={() => handleDelete(doc.id)}
													className="text-red-600 hover:text-red-700 hover:bg-red-50"
												>
													<Trash2 className="w-4 h-4" />
												</Button>
											</div>
										</CardContent>
									</Card>
								);
							})}
						</div>
					)}
				</CardContent>
			</Card>
		</div>
	);
}
