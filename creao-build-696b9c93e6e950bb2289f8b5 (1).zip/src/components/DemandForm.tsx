import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
	Select,
	SelectContent,
	SelectItem,
	SelectTrigger,
	SelectValue,
} from "@/components/ui/select";
import { ArrowLeft, Save } from "lucide-react";
import {
	DemandORM,
	DemandStatus,
	DemandPriority,
	DemandDemandType,
} from "@/components/data/orm/orm_demand";
import type { DemandModel } from "@/components/data/orm/orm_demand";
import { ClientORM } from "@/components/data/orm/orm_client";
import type { ClientModel } from "@/components/data/orm/orm_client";

interface DemandFormProps {
	onClose: () => void;
}

export function DemandForm({ onClose }: DemandFormProps) {
	const [loading, setLoading] = React.useState(false);
	const [clients, setClients] = React.useState<ClientModel[]>([]);
	const demandORM = React.useMemo(() => DemandORM.getInstance(), []);
	const clientORM = React.useMemo(() => ClientORM.getInstance(), []);

	const [formData, setFormData] = React.useState({
		client_id: "",
		demand_number: "",
		demand_type: DemandDemandType.Civil,
		status: DemandStatus.New,
		priority: DemandPriority.Medium,
		description: "",
	});

	React.useEffect(() => {
		loadClients();
	}, []);

	const loadClients = async () => {
		try {
			const data = await clientORM.getAllClient();
			setClients(data);
		} catch (error) {
			console.error("Error loading clients:", error);
		}
	};

	const handleSubmit = async (e: React.FormEvent) => {
		e.preventDefault();

		if (!formData.client_id) {
			alert("Por favor, selecione um cliente.");
			return;
		}

		try {
			setLoading(true);

			const now = new Date().toISOString();
			const newDemand: DemandModel = {
				id: crypto.randomUUID(),
				data_creator: "system",
				data_updater: "system",
				create_time: now,
				update_time: now,
				client_id: formData.client_id,
				demand_number: formData.demand_number || null,
				demand_type: formData.demand_type,
				priority: formData.priority,
				status: formData.status,
				dates: null,
				protocol_info: null,
				values: null,
				description: formData.description || null,
			};

			await demandORM.insertDemand([newDemand]);

			alert("Demanda cadastrada com sucesso!");
			onClose();
		} catch (error) {
			console.error("Error creating demand:", error);
			alert("Erro ao cadastrar demanda. Verifique os dados e tente novamente.");
		} finally {
			setLoading(false);
		}
	};

	return (
		<div className="space-y-6">
			<div className="flex items-center gap-4">
				<Button variant="ghost" onClick={onClose} className="gap-2">
					<ArrowLeft className="w-4 h-4" />
					Voltar
				</Button>
				<div>
					<h2 className="text-3xl font-bold text-gray-900">Nova Demanda</h2>
					<p className="text-sm text-gray-600 mt-1">Cadastre uma nova demanda</p>
				</div>
			</div>

			<Card>
				<CardHeader>
					<CardTitle>Dados da Demanda</CardTitle>
				</CardHeader>
				<CardContent>
					<form onSubmit={handleSubmit} className="space-y-4">
						<div className="grid grid-cols-1 md:grid-cols-2 gap-4">
							<div className="space-y-2 md:col-span-2">
								<Label htmlFor="client_id">Cliente *</Label>
								<Select
									value={formData.client_id}
									onValueChange={(value) =>
										setFormData({ ...formData, client_id: value })
									}
								>
									<SelectTrigger>
										<SelectValue placeholder="Selecione um cliente" />
									</SelectTrigger>
									<SelectContent>
										{clients.map((client) => (
											<SelectItem key={client.id} value={client.id}>
												{client.full_name}
											</SelectItem>
										))}
									</SelectContent>
								</Select>
							</div>

							<div className="space-y-2">
								<Label htmlFor="demand_number">Número da Demanda</Label>
								<Input
									id="demand_number"
									value={formData.demand_number}
									onChange={(e) =>
										setFormData({ ...formData, demand_number: e.target.value })
									}
									placeholder="Ex: 2025-001"
								/>
							</div>

							<div className="space-y-2">
								<Label htmlFor="demand_type">Tipo *</Label>
								<Select
									value={formData.demand_type.toString()}
									onValueChange={(value) =>
										setFormData({
											...formData,
											demand_type: Number.parseInt(value) as DemandDemandType,
										})
									}
								>
									<SelectTrigger>
										<SelectValue />
									</SelectTrigger>
									<SelectContent>
										<SelectItem value={DemandDemandType.Civil.toString()}>
											Cível
										</SelectItem>
										<SelectItem value={DemandDemandType.Criminal.toString()}>
											Criminal
										</SelectItem>
										<SelectItem value={DemandDemandType.Labor.toString()}>
											Trabalhista
										</SelectItem>
										<SelectItem value={DemandDemandType.Tax.toString()}>
											Tributário
										</SelectItem>
										<SelectItem
											value={DemandDemandType.Administrative.toString()}
										>
											Administrativo
										</SelectItem>
										<SelectItem
											value={DemandDemandType.SocialSecurity.toString()}
										>
											Previdenciário
										</SelectItem>
										<SelectItem value={DemandDemandType.Other.toString()}>
											Outro
										</SelectItem>
									</SelectContent>
								</Select>
							</div>

							<div className="space-y-2">
								<Label htmlFor="status">Status *</Label>
								<Select
									value={formData.status.toString()}
									onValueChange={(value) =>
										setFormData({
											...formData,
											status: Number.parseInt(value) as DemandStatus,
										})
									}
								>
									<SelectTrigger>
										<SelectValue />
									</SelectTrigger>
									<SelectContent>
										<SelectItem value={DemandStatus.New.toString()}>
											Nova
										</SelectItem>
										<SelectItem value={DemandStatus.InProgress.toString()}>
											Em Andamento
										</SelectItem>
										<SelectItem value={DemandStatus.Waiting.toString()}>
											Aguardando
										</SelectItem>
										<SelectItem value={DemandStatus.Suspended.toString()}>
											Suspensa
										</SelectItem>
										<SelectItem value={DemandStatus.Concluded.toString()}>
											Concluída
										</SelectItem>
										<SelectItem value={DemandStatus.Archived.toString()}>
											Arquivada
										</SelectItem>
									</SelectContent>
								</Select>
							</div>

							<div className="space-y-2">
								<Label htmlFor="priority">Prioridade *</Label>
								<Select
									value={formData.priority.toString()}
									onValueChange={(value) =>
										setFormData({
											...formData,
											priority: Number.parseInt(value) as DemandPriority,
										})
									}
								>
									<SelectTrigger>
										<SelectValue />
									</SelectTrigger>
									<SelectContent>
										<SelectItem value={DemandPriority.Low.toString()}>
											Baixa
										</SelectItem>
										<SelectItem value={DemandPriority.Medium.toString()}>
											Média
										</SelectItem>
										<SelectItem value={DemandPriority.High.toString()}>
											Alta
										</SelectItem>
										<SelectItem value={DemandPriority.Critical.toString()}>
											Crítica
										</SelectItem>
									</SelectContent>
								</Select>
							</div>

							<div className="space-y-2 md:col-span-2">
								<Label htmlFor="description">Descrição</Label>
								<Textarea
									id="description"
									value={formData.description}
									onChange={(e) =>
										setFormData({ ...formData, description: e.target.value })
									}
									placeholder="Descrição detalhada da demanda..."
									rows={4}
								/>
							</div>
						</div>

						<div className="flex gap-2 justify-end pt-4">
							<Button type="button" variant="outline" onClick={onClose}>
								Cancelar
							</Button>
							<Button type="submit" disabled={loading} className="gap-2">
								<Save className="w-4 h-4" />
								{loading ? "Salvando..." : "Salvar Demanda"}
							</Button>
						</div>
					</form>
				</CardContent>
			</Card>
		</div>
	);
}
