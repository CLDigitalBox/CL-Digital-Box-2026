import { useMutation, type UseMutationResult } from '@tanstack/react-query';
import { postV1AiZWwyutGgvEgWwzSaChatCompletions } from '@/sdk/api-clients/OpenAIGPTVision';
import { type PostV1AiZWwyutGgvEgWwzSaChatCompletionsResponses } from '@/sdk/api-clients/OpenAIGPTVision';

export type VisionMessageContent =
  | {
      type: 'text';
      text: string;
    }
  | {
      type: 'image_url';
      image_url: {
        url: string;
      };
    };

export interface VisionMessage {
  role: 'user';
  content: VisionMessageContent[];
}

export interface VisionCompletionInput {
  messages: VisionMessage[];
  stream?: boolean;
}

export interface VisionCompletionResponse {
  id: string;
  content: string;
  model: string;
  finishReason: string;
  usage: {
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
    reasoningTokens?: number;
  };
  created: number;
}

/**
 * Hook for analyzing images using OpenAI GPT Vision.
 *
 * This hook sends messages with text and images to the GPT Vision API
 * for image recognition and analysis. Supports multiple images and text prompts.
 *
 * @example
 * ```tsx
 * const visionMutation = useOpenAIGPTVisionMutation();
 *
 * const analyzeImage = async (imageUrl: string) => {
 *   try {
 *     const result = await visionMutation.mutateAsync({
 *       messages: [{
 *         role: 'user',
 *         content: [
 *           { type: 'text', text: 'What is in this image?' },
 *           { type: 'image_url', image_url: { url: imageUrl } }
 *         ]
 *       }]
 *     });
 *     console.log('Image analysis:', result.content);
 *   } catch (error) {
 *     console.error('Vision analysis failed:', error);
 *   }
 * };
 * ```
 */
export function useOpenAIGPTVisionMutation(): UseMutationResult<
  VisionCompletionResponse,
  Error,
  VisionCompletionInput
> {
  return useMutation({
    mutationFn: async (input: VisionCompletionInput): Promise<VisionCompletionResponse> => {
      // Validate input
      if (!input.messages || input.messages.length === 0) {
        throw new Error('At least one message is required');
      }

      // Validate message structure
      for (const message of input.messages) {
        if (message.role !== 'user') {
          throw new Error('Vision API only supports "user" role messages');
        }

        if (!message.content || message.content.length === 0) {
          throw new Error('Each message must have content');
        }

        // Validate content items
        for (const contentItem of message.content) {
          if (contentItem.type === 'text') {
            if (!contentItem.text) {
              throw new Error('Text content items must have a "text" field');
            }
          } else if (contentItem.type === 'image_url') {
            if (!contentItem.image_url || !contentItem.image_url.url) {
              throw new Error('Image content items must have an "image_url.url" field');
            }
          } else {
            throw new Error('Content type must be "text" or "image_url"');
          }
        }
      }

      // Make API request
      const response = await postV1AiZWwyutGgvEgWwzSaChatCompletions({
        body: {
          messages: input.messages,
          stream: input.stream || false,
        },
        headers: {
          'X-CREAO-API-NAME': 'OpenAIGPTVision',
          'X-CREAO-API-PATH': '/v1/ai/zWwyutGgvEGWwzSa/chat/completions',
          'X-CREAO-API-ID': '68a5655cdeb2a0b2f64c013d',
        },
      });

      // Handle API errors
      if (response.error) {
        throw new Error('Vision completion request failed. Please check your authentication and image URLs.');
      }

      // Validate response data
      if (!response.data) {
        throw new Error('No response data received from vision API');
      }

      const data = response.data as PostV1AiZWwyutGgvEgWwzSaChatCompletionsResponses[200];

      // Validate required response fields
      if (!data.choices || data.choices.length === 0) {
        throw new Error('No choices returned in vision completion response');
      }

      const firstChoice = data.choices[0];
      if (!firstChoice.message || !firstChoice.message.content) {
        throw new Error('No message content in vision completion response');
      }

      // Return structured response
      return {
        id: data.id,
        content: firstChoice.message.content,
        model: data.model,
        finishReason: firstChoice.finish_reason,
        usage: {
          promptTokens: data.usage.prompt_tokens,
          completionTokens: data.usage.completion_tokens,
          totalTokens: data.usage.total_tokens,
          reasoningTokens: data.usage.completion_tokens_details?.reasoning_tokens,
        },
        created: data.created,
      };
    },
  });
}
