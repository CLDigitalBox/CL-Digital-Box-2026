import { useMutation, type UseMutationResult } from '@tanstack/react-query';
import { createChatCompletion } from '@/sdk/api-clients/OpenAIGPTChat';
import { type CreateChatCompletionResponses } from '@/sdk/api-clients/OpenAIGPTChat';

export interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export interface ChatCompletionInput {
  messages: ChatMessage[];
  model?: string;
}

export interface ChatCompletionResponse {
  id: string;
  content: string;
  model: string;
  finishReason: string;
  usage: {
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
    reasoningTokens?: number;
  };
  created: number;
}

/**
 * Hook for creating chat completions using OpenAI GPT.
 *
 * This hook sends messages to the OpenAI GPT API and receives AI-generated responses.
 * Supports system prompts, conversation history, and usage tracking.
 *
 * @example
 * ```tsx
 * const chatMutation = useOpenAIGPTChatMutation();
 *
 * const handleChat = async () => {
 *   try {
 *     const result = await chatMutation.mutateAsync({
 *       messages: [
 *         { role: 'system', content: 'You are a helpful assistant.' },
 *         { role: 'user', content: 'Hello, how are you?' }
 *       ],
 *       model: 'MaaS_4.1'
 *     });
 *     console.log('AI Response:', result.content);
 *     console.log('Tokens used:', result.usage.totalTokens);
 *   } catch (error) {
 *     console.error('Chat failed:', error);
 *   }
 * };
 * ```
 */
export function useOpenAIGPTChatMutation(): UseMutationResult<
  ChatCompletionResponse,
  Error,
  ChatCompletionInput
> {
  return useMutation({
    mutationFn: async (input: ChatCompletionInput): Promise<ChatCompletionResponse> => {
      // Validate input
      if (!input.messages || input.messages.length === 0) {
        throw new Error('At least one message is required');
      }

      // Validate message structure
      for (const message of input.messages) {
        if (!message.role || !message.content) {
          throw new Error('Each message must have a role and content');
        }
        if (!['system', 'user', 'assistant'].includes(message.role)) {
          throw new Error('Message role must be "system", "user", or "assistant"');
        }
      }

      // Make API request
      const response = await createChatCompletion({
        body: {
          model: input.model || 'MaaS_4.1',
          messages: input.messages,
        },
        headers: {
          'X-CREAO-API-NAME': 'OpenAIGPTChat',
          'X-CREAO-API-PATH': '/v1/ai/zWwyutGgvEGWwzSa/chat/completions',
          'X-CREAO-API-ID': '688a0b64dc79a2533460892c',
        },
      });

      // Handle API errors
      if (response.error) {
        throw new Error('Chat completion request failed. Please check your authentication and try again.');
      }

      // Validate response data
      if (!response.data) {
        throw new Error('No response data received from chat API');
      }

      const data = response.data as CreateChatCompletionResponses[200];

      // Validate required response fields
      if (!data.choices || data.choices.length === 0) {
        throw new Error('No choices returned in chat completion response');
      }

      const firstChoice = data.choices[0];
      if (!firstChoice.message || !firstChoice.message.content) {
        throw new Error('No message content in chat completion response');
      }

      // Return structured response
      return {
        id: data.id,
        content: firstChoice.message.content,
        model: data.model,
        finishReason: firstChoice.finish_reason,
        usage: {
          promptTokens: data.usage.prompt_tokens,
          completionTokens: data.usage.completion_tokens,
          totalTokens: data.usage.total_tokens,
          reasoningTokens: data.usage.completion_tokens_details?.reasoning_tokens,
        },
        created: data.created,
      };
    },
  });
}
