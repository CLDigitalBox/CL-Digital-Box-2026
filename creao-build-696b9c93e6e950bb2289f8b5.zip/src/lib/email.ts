/**
 * Email Service - Integração com Resend API
 *
 * Este módulo fornece funções para envio de emails via Resend (https://resend.com)
 *
 * IMPORTANTE: Para usar em produção, você precisa:
 * 1. Criar conta em https://resend.com
 * 2. Adicionar e verificar seu domínio
 * 3. Obter sua API Key
 * 4. Configurar variável de ambiente VITE_RESEND_API_KEY
 */

export interface EmailOptions {
	to: string | string[];
	subject: string;
	html?: string;
	text?: string;
	from?: string;
	replyTo?: string;
	attachments?: {
		filename: string;
		content: string | Buffer;
	}[];
}

export interface EmailResponse {
	success: boolean;
	messageId?: string;
	error?: string;
}

/**
 * Envia email via Resend API
 *
 * @param options - Opções do email
 * @returns Resposta com sucesso ou erro
 */
export async function sendEmail(options: EmailOptions): Promise<EmailResponse> {
	// Verifica se API key está configurada
	const apiKey = import.meta.env.VITE_RESEND_API_KEY;
	const fromEmail = import.meta.env.VITE_DEFAULT_FROM_EMAIL || "CL Assessoria <contato@clprocessosdigitais.com.br>";
	const replyToEmail = import.meta.env.VITE_REPLY_TO_EMAIL || "processosgerais22@gmail.com";

	if (!apiKey || apiKey === "re_YOUR_API_KEY_HERE") {
		console.warn("⚠️ VITE_RESEND_API_KEY não configurada. Simulando envio de email...");
		console.warn("📝 Configure sua chave em .env.local para habilitar envio real");
		console.warn("🔗 Obtenha em: https://resend.com/api-keys");
		console.warn("");
		console.warn("📧 Configurações de email atuais:");
		console.warn(`   De: ${fromEmail}`);
		console.warn(`   Reply-To: ${replyToEmail}`);
		return simulateEmailSend(options, fromEmail, replyToEmail);
	}

	try {
		const response = await fetch("https://api.resend.com/emails", {
			method: "POST",
			headers: {
				"Authorization": `Bearer ${apiKey}`,
				"Content-Type": "application/json",
			},
			body: JSON.stringify({
				from: options.from || fromEmail,
				to: Array.isArray(options.to) ? options.to : [options.to],
				subject: options.subject,
				html: options.html || undefined,
				text: options.text || undefined,
				reply_to: options.replyTo || replyToEmail,
				attachments: options.attachments || undefined,
			}),
		});

		if (!response.ok) {
			const error = await response.json();
			console.error("❌ Erro Resend API:", error);
			throw new Error(error.message || "Erro ao enviar email");
		}

		const data = await response.json();

		console.log("✅ Email enviado com sucesso via Resend!");
		console.log("📧 ID:", data.id);
		console.log("📨 Para:", options.to);

		return {
			success: true,
			messageId: data.id,
		};
	} catch (error) {
		console.error("❌ Erro ao enviar email:", error);

		return {
			success: false,
			error: (error as Error).message,
		};
	}
}

/**
 * Simula envio de email quando API key não está configurada
 */
function simulateEmailSend(
	options: EmailOptions,
	defaultFrom: string,
	defaultReplyTo: string
): Promise<EmailResponse> {
	return new Promise((resolve) => {
		setTimeout(() => {
			console.log("=== EMAIL SIMULADO ===");
			console.log("De:", options.from || defaultFrom);
			console.log("Para:", options.to);
			console.log("Reply-To:", options.replyTo || defaultReplyTo);
			console.log("Assunto:", options.subject);
			console.log("Conteúdo HTML:", options.html ? "Sim" : "Não");
			console.log("Conteúdo Texto:", options.text || "");
			console.log("=====================");

			resolve({
				success: true,
				messageId: `simulated-${Date.now()}`,
			});
		}, 1000);
	});
}

/**
 * Template de email para relatórios PDF
 */
export function createReportEmailTemplate(
	clientName: string,
	reportType: string,
	pdfUrl: string
): string {
	return `
<!DOCTYPE html>
<html lang="pt-BR">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Relatório PDF - CL Assessoria</title>
	<style>
		body {
			font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
			line-height: 1.6;
			color: #333;
			max-width: 600px;
			margin: 0 auto;
			padding: 20px;
		}
		.header {
			background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
			color: white;
			padding: 30px;
			border-radius: 10px 10px 0 0;
			text-align: center;
		}
		.content {
			background: #f9fafb;
			padding: 30px;
			border-radius: 0 0 10px 10px;
		}
		.button {
			display: inline-block;
			background: #2563eb;
			color: white;
			padding: 12px 30px;
			text-decoration: none;
			border-radius: 6px;
			font-weight: 600;
			margin: 20px 0;
		}
		.footer {
			text-align: center;
			margin-top: 30px;
			padding-top: 20px;
			border-top: 1px solid #e5e7eb;
			color: #6b7280;
			font-size: 14px;
		}
	</style>
</head>
<body>
	<div class="header">
		<h1 style="margin: 0;">📄 Relatório Disponível</h1>
	</div>
	<div class="content">
		<p>Olá <strong>${clientName}</strong>,</p>

		<p>Seu relatório <strong>${reportType}</strong> foi gerado com sucesso e está pronto para download.</p>

		<p style="text-align: center;">
			<a href="${pdfUrl}" class="button">📥 Baixar Relatório PDF</a>
		</p>

		<p><strong>Informações do Relatório:</strong></p>
		<ul>
			<li>Tipo: ${reportType}</li>
			<li>Data de Geração: ${new Date().toLocaleString("pt-BR")}</li>
			<li>Formato: PDF</li>
		</ul>

		<p>Se tiver alguma dúvida, estamos à disposição!</p>

		<p>Atenciosamente,<br>
		<strong>CL Assessoria e Consultoria Digital</strong><br>
		Santa Bárbara, MG</p>
	</div>
	<div class="footer">
		<p>Este é um email automático. Por favor, não responda.</p>
		<p>CL Assessoria © ${new Date().getFullYear()} - Todos os direitos reservados</p>
	</div>
</body>
</html>
	`.trim();
}

/**
 * Template de email para notificações
 */
export function createNotificationEmailTemplate(
	clientName: string,
	subject: string,
	message: string
): string {
	return `
<!DOCTYPE html>
<html lang="pt-BR">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>${subject}</title>
	<style>
		body {
			font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
			line-height: 1.6;
			color: #333;
			max-width: 600px;
			margin: 0 auto;
			padding: 20px;
		}
		.header {
			background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
			color: white;
			padding: 30px;
			border-radius: 10px 10px 0 0;
			text-align: center;
		}
		.content {
			background: #f9fafb;
			padding: 30px;
			border-radius: 0 0 10px 10px;
		}
		.message-box {
			background: white;
			border-left: 4px solid #2563eb;
			padding: 15px;
			margin: 20px 0;
			border-radius: 4px;
		}
		.footer {
			text-align: center;
			margin-top: 30px;
			padding-top: 20px;
			border-top: 1px solid #e5e7eb;
			color: #6b7280;
			font-size: 14px;
		}
	</style>
</head>
<body>
	<div class="header">
		<h1 style="margin: 0;">🔔 ${subject}</h1>
	</div>
	<div class="content">
		<p>Olá <strong>${clientName}</strong>,</p>

		<div class="message-box">
			<p style="white-space: pre-wrap; margin: 0;">${message}</p>
		</div>

		<p>Se tiver alguma dúvida, estamos à disposição!</p>

		<p>Atenciosamente,<br>
		<strong>CL Assessoria e Consultoria Digital</strong><br>
		Santa Bárbara, MG</p>
	</div>
	<div class="footer">
		<p>Este é um email automático. Por favor, não responda.</p>
		<p>CL Assessoria © ${new Date().getFullYear()} - Todos os direitos reservados</p>
	</div>
</body>
</html>
	`.trim();
}
