/**
 * Utility functions for date calculations related to installment payments
 */

/**
 * Check if a date is a weekend (Saturday or Sunday)
 */
export function isWeekend(date: Date): boolean {
	const day = date.getDay();
	return day === 0 || day === 6; // 0 = Sunday, 6 = Saturday
}

/**
 * Brazilian national holidays (fixed dates)
 * Note: This is a simplified version. For production, consider using a comprehensive holiday library.
 */
const FIXED_HOLIDAYS = [
	{ month: 0, day: 1 },   // New Year's Day
	{ month: 3, day: 21 },  // Tiradentes Day
	{ month: 4, day: 1 },   // Labour Day
	{ month: 8, day: 7 },   // Independence Day
	{ month: 9, day: 12 },  // Our Lady of Aparecida
	{ month: 10, day: 2 },  // All Souls' Day
	{ month: 10, day: 15 }, // Proclamation of the Republic
	{ month: 10, day: 20 }, // Black Consciousness Day
	{ month: 11, day: 25 }, // Christmas Day
];

/**
 * Check if a date is a Brazilian national holiday
 * Note: This only checks fixed holidays. Moveable holidays like Carnival and Easter are not included.
 */
export function isNationalHoliday(date: Date): boolean {
	const month = date.getMonth();
	const day = date.getDate();

	return FIXED_HOLIDAYS.some(holiday =>
		holiday.month === month && holiday.day === day
	);
}

/**
 * Check if a date is a business day (not weekend and not holiday)
 */
export function isBusinessDay(date: Date): boolean {
	return !isWeekend(date) && !isNationalHoliday(date);
}

/**
 * Get the last day of a given month
 */
export function getLastDayOfMonth(year: number, month: number): Date {
	// Month is 0-indexed, so next month's day 0 gives us the last day of current month
	return new Date(year, month + 1, 0);
}

/**
 * Get the penultimate business day of a given month
 * This is commonly used for tax payment deadlines in Brazil
 *
 * @param year The year
 * @param month The month (0-indexed, 0 = January)
 * @returns Date object representing the penultimate business day
 */
export function getPenultimateBusinessDay(year: number, month: number): Date {
	let date = getLastDayOfMonth(year, month);
	let businessDaysFound = 0;

	// Count backwards from the last day of the month
	while (businessDaysFound < 2) {
		if (isBusinessDay(date)) {
			businessDaysFound++;
			if (businessDaysFound === 2) {
				break;
			}
		}
		// Move to previous day
		date = new Date(date);
		date.setDate(date.getDate() - 1);
	}

	return date;
}

/**
 * Generate due dates for all installments of a payment plan
 * Each installment is due on the penultimate business day of each month
 *
 * @param startYear Starting year
 * @param startMonth Starting month (0-indexed)
 * @param numberOfInstallments Total number of installments
 * @returns Array of Date objects representing due dates
 */
export function generateInstallmentDueDates(
	startYear: number,
	startMonth: number,
	numberOfInstallments: number
): Date[] {
	const dueDates: Date[] = [];

	for (let i = 0; i < numberOfInstallments; i++) {
		const currentMonth = (startMonth + i) % 12;
		const currentYear = startYear + Math.floor((startMonth + i) / 12);

		const dueDate = getPenultimateBusinessDay(currentYear, currentMonth);
		dueDates.push(dueDate);
	}

	return dueDates;
}

/**
 * Format a date as ISO string (YYYY-MM-DD)
 * Useful for storing dates in the database
 */
export function toISODateString(date: Date): string {
	const year = date.getFullYear();
	const month = String(date.getMonth() + 1).padStart(2, '0');
	const day = String(date.getDate()).padStart(2, '0');
	return `${year}-${month}-${day}`;
}

/**
 * Calculate the number of days between two dates
 */
export function daysBetween(date1: Date, date2: Date): number {
	const oneDay = 24 * 60 * 60 * 1000; // hours * minutes * seconds * milliseconds
	const diffDays = Math.round(Math.abs((date1.getTime() - date2.getTime()) / oneDay));
	return diffDays;
}

/**
 * Check if a due date is approaching (within specified days)
 */
export function isDueApproaching(dueDate: Date, daysThreshold: number = 7): boolean {
	const today = new Date();
	today.setHours(0, 0, 0, 0);

	const due = new Date(dueDate);
	due.setHours(0, 0, 0, 0);

	const daysUntilDue = Math.ceil((due.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

	return daysUntilDue >= 0 && daysUntilDue <= daysThreshold;
}

/**
 * Check if a payment is overdue
 */
export function isOverdue(dueDate: Date): boolean {
	const today = new Date();
	today.setHours(0, 0, 0, 0);

	const due = new Date(dueDate);
	due.setHours(0, 0, 0, 0);

	return due < today;
}
