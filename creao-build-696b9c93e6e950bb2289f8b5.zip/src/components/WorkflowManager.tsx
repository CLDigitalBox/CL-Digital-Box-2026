import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
	FileText,
	Car,
	Users,
	Building2,
	Briefcase,
	CheckCircle2,
	Clock,
	AlertCircle,
	Play,
	Pause,
	XCircle,
} from "lucide-react";
import { DemandORM, type DemandModel, DemandDemandType, DemandStatus } from "@/components/data/orm/orm_demand";
import { ClientORM, type ClientModel } from "@/components/data/orm/orm_client";

/**
 * Tipos de workflow jurídico disponíveis
 */
const WORKFLOW_TYPES = {
	TaxistaIPIICMS: {
		id: "taxista_ipi_icms",
		name: "Isenção IPI/ICMS Taxista",
		icon: Car,
		color: "bg-blue-500",
		demandType: DemandDemandType.Tax,
		steps: [
			"Coleta de documentação pessoal",
			"Verificação de CNH categoria B",
			"Análise de comprovante de atividade",
			"Preenchimento de formulários IPI/ICMS",
			"Protocolo na Receita Federal",
			"Acompanhamento de liberação",
		],
	},
	PCDIPIICMS: {
		id: "pcd_ipi_icms",
		name: "Isenção IPI/ICMS PCD",
		icon: Users,
		color: "bg-green-500",
		demandType: DemandDemandType.Tax,
		steps: [
			"Coleta de laudo médico",
			"Verificação de documentos PCD",
			"Análise de capacidade financeira",
			"Preenchimento de formulários IPI/ICMS",
			"Protocolo na Receita Federal e DETRAN",
			"Acompanhamento de liberação",
		],
	},
	ProcessoRFB: {
		id: "processo_rfb",
		name: "Processo Receita Federal",
		icon: Building2,
		color: "bg-purple-500",
		demandType: DemandDemandType.Tax,
		steps: [
			"Análise de notificação fiscal",
			"Levantamento de documentação",
			"Elaboração de defesa",
			"Protocolo de impugnação",
			"Acompanhamento administrativo",
			"Recurso se necessário",
		],
	},
	ProcessoINSS: {
		id: "processo_inss",
		name: "Processo INSS",
		icon: Briefcase,
		color: "bg-orange-500",
		demandType: DemandDemandType.SocialSecurity,
		steps: [
			"Análise de benefício negado",
			"Coleta de documentação previdenciária",
			"Elaboração de recurso administrativo",
			"Protocolo no INSS",
			"Acompanhamento de perícia médica",
			"Revisão de decisão",
		],
	},
	ProcessosDiversos: {
		id: "processos_diversos",
		name: "Processos Diversos",
		icon: FileText,
		color: "bg-gray-500",
		demandType: DemandDemandType.Other,
		steps: [
			"Análise inicial da demanda",
			"Definição de estratégia",
			"Coleta de documentação",
			"Execução de procedimentos",
			"Acompanhamento de prazos",
			"Conclusão do processo",
		],
	},
};

/**
 * Calcula o progresso do workflow baseado nos status da demand
 */
function calculateProgress(status: DemandStatus, totalSteps: number): number {
	switch (status) {
		case DemandStatus.New:
			return 0;
		case DemandStatus.InProgress:
			return 50;
		case DemandStatus.Waiting:
			return 60;
		case DemandStatus.Suspended:
			return 40;
		case DemandStatus.Concluded:
			return 100;
		case DemandStatus.Archived:
			return 100;
		default:
			return 0;
	}
}

/**
 * Retorna o ícone e cor do status
 */
function getStatusInfo(status: DemandStatus) {
	switch (status) {
		case DemandStatus.New:
			return { icon: Clock, color: "text-gray-500", label: "Novo" };
		case DemandStatus.InProgress:
			return { icon: Play, color: "text-blue-500", label: "Em Andamento" };
		case DemandStatus.Waiting:
			return { icon: Pause, color: "text-yellow-500", label: "Aguardando" };
		case DemandStatus.Suspended:
			return { icon: AlertCircle, color: "text-orange-500", label: "Suspenso" };
		case DemandStatus.Concluded:
			return { icon: CheckCircle2, color: "text-green-500", label: "Concluído" };
		case DemandStatus.Archived:
			return { icon: XCircle, color: "text-gray-400", label: "Arquivado" };
		default:
			return { icon: Clock, color: "text-gray-500", label: "Desconhecido" };
	}
}

export function WorkflowManager() {
	const [workflows, setWorkflows] = React.useState<DemandModel[]>([]);
	const [clients, setClients] = React.useState<Map<string, ClientModel>>(new Map());
	const [loading, setLoading] = React.useState(true);
	const [activeType, setActiveType] = React.useState("all");

	const demandORM = React.useMemo(() => DemandORM.getInstance(), []);
	const clientORM = React.useMemo(() => ClientORM.getInstance(), []);

	React.useEffect(() => {
		loadWorkflows();
	}, []);

	const loadWorkflows = async () => {
		try {
			setLoading(true);
			const [allDemands, allClients] = await Promise.all([
				demandORM.getAllDemand(),
				clientORM.getAllClient(),
			]);

			// Criar mapa de clientes para acesso rápido
			const clientMap = new Map<string, ClientModel>();
			allClients.forEach((client: ClientModel) => {
				clientMap.set(client.id, client);
			});

			setWorkflows(allDemands);
			setClients(clientMap);
		} catch (error) {
			console.error("Erro ao carregar workflows:", error);
		} finally {
			setLoading(false);
		}
	};

	const filterWorkflows = (type: string) => {
		if (type === "all") return workflows;
		const workflowConfig = Object.values(WORKFLOW_TYPES).find((w) => w.id === type);
		if (!workflowConfig) return workflows;
		return workflows.filter((w) => w.demand_type === workflowConfig.demandType);
	};

	const filteredWorkflows = filterWorkflows(activeType);

	return (
		<div className="space-y-6">
			<div>
				<h2 className="text-3xl font-bold text-gray-900">Módulo de Workflows</h2>
				<p className="text-sm text-gray-600 mt-1">
					Gestão de fluxos de trabalho jurídicos e administrativos
				</p>
			</div>

			<Tabs value={activeType} onValueChange={setActiveType} className="w-full">
				<TabsList className="grid w-full grid-cols-6 h-auto">
					<TabsTrigger value="all" className="gap-2 py-3">
						<FileText className="h-4 w-4" />
						<span>Todos</span>
					</TabsTrigger>
					{Object.values(WORKFLOW_TYPES).map((workflow) => {
						const Icon = workflow.icon;
						return (
							<TabsTrigger key={workflow.id} value={workflow.id} className="gap-2 py-3">
								<Icon className="h-4 w-4" />
								<span className="hidden lg:inline">{workflow.name}</span>
								<span className="lg:hidden">
									{workflow.name.split(" ")[0]}
								</span>
							</TabsTrigger>
						);
					})}
				</TabsList>

				<TabsContent value={activeType} className="mt-6">
					{loading ? (
						<Card>
							<CardContent className="p-8 text-center text-gray-500">
								Carregando workflows...
							</CardContent>
						</Card>
					) : filteredWorkflows.length === 0 ? (
						<Card>
							<CardContent className="p-8 text-center text-gray-500">
								Nenhum workflow encontrado. Crie uma demanda para começar.
							</CardContent>
						</Card>
					) : (
						<div className="grid gap-4">
							{filteredWorkflows.map((workflow) => {
								const client = clients.get(workflow.client_id);
								const workflowType = Object.values(WORKFLOW_TYPES).find(
									(w) => w.demandType === workflow.demand_type
								);
								const statusInfo = getStatusInfo(workflow.status);
								const StatusIcon = statusInfo.icon;
								const progress = calculateProgress(
									workflow.status,
									workflowType?.steps.length || 6
								);

								return (
									<Card key={workflow.id}>
										<CardHeader>
											<div className="flex items-start justify-between">
												<div className="flex-1">
													<div className="flex items-center gap-3 mb-2">
														{workflowType && (
															<div
																className={`p-2 rounded-lg ${workflowType.color} text-white`}
															>
																<workflowType.icon className="h-5 w-5" />
															</div>
														)}
														<div>
															<CardTitle className="text-lg">
																{workflow.demand_number || "Sem número"}
															</CardTitle>
															<CardDescription>
																{client?.full_name || "Cliente não identificado"}
															</CardDescription>
														</div>
													</div>
												</div>
												<Badge variant="outline" className="ml-4">
													<StatusIcon className={`h-3 w-3 mr-1 ${statusInfo.color}`} />
													{statusInfo.label}
												</Badge>
											</div>
										</CardHeader>
										<CardContent className="space-y-4">
											<div>
												<div className="flex items-center justify-between text-sm mb-2">
													<span className="text-gray-600">Progresso do workflow</span>
													<span className="font-medium">{progress}%</span>
												</div>
												<Progress value={progress} className="h-2" />
											</div>

											{workflowType && (
												<div>
													<h4 className="text-sm font-medium mb-2 text-gray-700">
														Etapas do fluxo:
													</h4>
													<div className="space-y-2">
														{workflowType.steps.map((step, index) => {
															const stepComplete = (progress / 100) * workflowType.steps.length > index;
															return (
																<div
																	key={index}
																	className="flex items-center gap-2 text-sm"
																>
																	{stepComplete ? (
																		<CheckCircle2 className="h-4 w-4 text-green-500 flex-shrink-0" />
																	) : (
																		<div className="h-4 w-4 rounded-full border-2 border-gray-300 flex-shrink-0" />
																	)}
																	<span
																		className={
																			stepComplete
																				? "text-gray-900"
																				: "text-gray-500"
																		}
																	>
																		{index + 1}. {step}
																	</span>
																</div>
															);
														})}
													</div>
												</div>
											)}

											{workflow.description && (
												<div>
													<h4 className="text-sm font-medium mb-1 text-gray-700">
														Descrição:
													</h4>
													<p className="text-sm text-gray-600">{workflow.description}</p>
												</div>
											)}

											<div className="flex gap-2 pt-2">
												<Button size="sm" variant="outline" className="flex-1">
													Ver Detalhes
												</Button>
												<Button size="sm" className="flex-1">
													Avançar Etapa
												</Button>
											</div>
										</CardContent>
									</Card>
								);
							})}
						</div>
					)}
				</TabsContent>
			</Tabs>
		</div>
	);
}
