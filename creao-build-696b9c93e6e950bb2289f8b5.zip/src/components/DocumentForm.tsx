import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
	Select,
	SelectContent,
	SelectItem,
	SelectTrigger,
	SelectValue,
} from "@/components/ui/select";
import { ArrowLeft, Save, Upload } from "lucide-react";
import {
	DocumentORM,
	DocumentStatus,
	DocumentDocumentType,
} from "@/components/data/orm/orm_document";
import type { DocumentModel } from "@/components/data/orm/orm_document";
import { ClientORM } from "@/components/data/orm/orm_client";
import type { ClientModel } from "@/components/data/orm/orm_client";
import { DemandORM } from "@/components/data/orm/orm_demand";
import type { DemandModel } from "@/components/data/orm/orm_demand";

interface DocumentFormProps {
	onClose: () => void;
}

export function DocumentForm({ onClose }: DocumentFormProps) {
	const [loading, setLoading] = React.useState(false);
	const [clients, setClients] = React.useState<ClientModel[]>([]);
	const [demands, setDemands] = React.useState<DemandModel[]>([]);
	const [selectedFile, setSelectedFile] = React.useState<File | null>(null);
	const documentORM = React.useMemo(() => DocumentORM.getInstance(), []);
	const clientORM = React.useMemo(() => ClientORM.getInstance(), []);
	const demandORM = React.useMemo(() => DemandORM.getInstance(), []);

	const [formData, setFormData] = React.useState({
		client_id: "",
		demand_id: "",
		document_type: DocumentDocumentType.Other,
		status: DocumentStatus.Valid,
		description: "",
		issue_date: "",
		expiration_date: "",
		issuer: "",
		notes: "",
	});

	React.useEffect(() => {
		loadClients();
		loadDemands();
	}, []);

	const loadClients = async () => {
		try {
			const data = await clientORM.getAllClient();
			setClients(data);
		} catch (error) {
			console.error("Error loading clients:", error);
		}
	};

	const loadDemands = async () => {
		try {
			const data = await demandORM.getAllDemand();
			setDemands(data);
		} catch (error) {
			console.error("Error loading demands:", error);
		}
	};

	const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
		const file = e.target.files?.[0];
		if (file) {
			setSelectedFile(file);
		}
	};

	const handleSubmit = async (e: React.FormEvent) => {
		e.preventDefault();

		if (!formData.client_id) {
			alert("Por favor, selecione um cliente.");
			return;
		}

		if (!selectedFile) {
			alert("Por favor, selecione um arquivo para upload.");
			return;
		}

		try {
			setLoading(true);

			// Simular upload do arquivo (em produção, você faria upload para um servidor)
			// Por enquanto, vamos usar uma URL fictícia
			const fileUrl = `https://storage.example.com/documents/${selectedFile.name}`;

			const now = new Date().toISOString();
			const newDocument: DocumentModel = {
				id: crypto.randomUUID(),
				data_creator: "system",
				data_updater: "system",
				create_time: now,
				update_time: now,
				client_id: formData.client_id,
				demand_id: formData.demand_id || null,
				document_type: formData.document_type,
				status: formData.status,
				file_info: {
					file_name: selectedFile.name,
					file_size: selectedFile.size,
					mime_type: selectedFile.type || "application/octet-stream",
					file_url: fileUrl,
				},
				metadata: {
					issue_date: formData.issue_date || null,
					expiry_date: formData.expiration_date || null,
					issuer: formData.issuer || null,
					notes: formData.notes || null,
				},
			};

			await documentORM.insertDocument([newDocument]);

			alert("Documento cadastrado com sucesso!");
			onClose();
		} catch (error) {
			console.error("Error creating document:", error);
			alert("Erro ao cadastrar documento. Verifique os dados e tente novamente.");
		} finally {
			setLoading(false);
		}
	};

	return (
		<div className="space-y-6">
			<div className="flex items-center gap-4">
				<Button variant="ghost" onClick={onClose} className="gap-2">
					<ArrowLeft className="w-4 h-4" />
					Voltar
				</Button>
				<div>
					<h2 className="text-3xl font-bold text-gray-900">Novo Documento</h2>
					<p className="text-sm text-gray-600 mt-1">
						Cadastre um novo documento no sistema
					</p>
				</div>
			</div>

			<Card>
				<CardHeader>
					<CardTitle>Upload de Documento</CardTitle>
				</CardHeader>
				<CardContent>
					<form onSubmit={handleSubmit} className="space-y-4">
						<div className="grid grid-cols-1 md:grid-cols-2 gap-4">
							<div className="space-y-2 md:col-span-2">
								<Label htmlFor="client_id">Cliente *</Label>
								<Select
									value={formData.client_id}
									onValueChange={(value) =>
										setFormData({ ...formData, client_id: value })
									}
								>
									<SelectTrigger>
										<SelectValue placeholder="Selecione um cliente" />
									</SelectTrigger>
									<SelectContent>
										{clients.map((client) => (
											<SelectItem key={client.id} value={client.id}>
												{client.full_name}
											</SelectItem>
										))}
									</SelectContent>
								</Select>
							</div>

							<div className="space-y-2 md:col-span-2">
								<Label htmlFor="demand_id">Demanda (Opcional)</Label>
								<Select
									value={formData.demand_id}
									onValueChange={(value) =>
										setFormData({ ...formData, demand_id: value === "none" ? "" : value })
									}
								>
									<SelectTrigger>
										<SelectValue placeholder="Selecione uma demanda (opcional)" />
									</SelectTrigger>
									<SelectContent>
										<SelectItem value="none">Nenhuma</SelectItem>
										{demands.map((demand) => {
											const client = clients.find((c) => c.id === demand.client_id);
											return (
												<SelectItem key={demand.id} value={demand.id}>
													{demand.demand_number || "Sem número"} - {client?.full_name}
												</SelectItem>
											);
										})}
									</SelectContent>
								</Select>
							</div>

							<div className="space-y-2">
								<Label htmlFor="document_type">Tipo de Documento *</Label>
								<Select
									value={formData.document_type.toString()}
									onValueChange={(value) =>
										setFormData({
											...formData,
											document_type: Number.parseInt(value) as DocumentDocumentType,
										})
									}
								>
									<SelectTrigger>
										<SelectValue />
									</SelectTrigger>
									<SelectContent>
										<SelectItem value={DocumentDocumentType.Identification.toString()}>
											Identificação
										</SelectItem>
										<SelectItem value={DocumentDocumentType.AddressProof.toString()}>
											Comprovante de Endereço
										</SelectItem>
										<SelectItem value={DocumentDocumentType.Contract.toString()}>
											Contrato
										</SelectItem>
										<SelectItem value={DocumentDocumentType.LegalProcess.toString()}>
											Processo Legal
										</SelectItem>
										<SelectItem value={DocumentDocumentType.Evidence.toString()}>
											Prova/Evidência
										</SelectItem>
										<SelectItem value={DocumentDocumentType.Invoice.toString()}>
											Nota Fiscal
										</SelectItem>
										<SelectItem value={DocumentDocumentType.Other.toString()}>
											Outro
										</SelectItem>
									</SelectContent>
								</Select>
							</div>

							<div className="space-y-2">
								<Label htmlFor="status">Status *</Label>
								<Select
									value={formData.status.toString()}
									onValueChange={(value) =>
										setFormData({
											...formData,
											status: Number.parseInt(value) as DocumentStatus,
										})
									}
								>
									<SelectTrigger>
										<SelectValue />
									</SelectTrigger>
									<SelectContent>
										<SelectItem value={DocumentStatus.Pending.toString()}>
											Pendente
										</SelectItem>
										<SelectItem value={DocumentStatus.Valid.toString()}>
											Válido
										</SelectItem>
										<SelectItem value={DocumentStatus.Rejected.toString()}>
											Rejeitado
										</SelectItem>
										<SelectItem value={DocumentStatus.Expired.toString()}>
											Expirado
										</SelectItem>
										<SelectItem value={DocumentStatus.Archived.toString()}>
											Arquivado
										</SelectItem>
									</SelectContent>
								</Select>
							</div>

							<div className="space-y-2 md:col-span-2">
								<Label htmlFor="file">Arquivo *</Label>
								<div className="flex items-center gap-2">
									<Input
										id="file"
										type="file"
										onChange={handleFileChange}
										accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
										required
										className="flex-1"
									/>
									<Upload className="w-4 h-4 text-gray-400" />
								</div>
								{selectedFile && (
									<p className="text-sm text-gray-600">
										Arquivo selecionado: {selectedFile.name} ({(selectedFile.size / 1024).toFixed(1)} KB)
									</p>
								)}
							</div>

							<div className="space-y-2">
								<Label htmlFor="issue_date">Data de Emissão</Label>
								<Input
									id="issue_date"
									type="date"
									value={formData.issue_date}
									onChange={(e) => setFormData({ ...formData, issue_date: e.target.value })}
								/>
							</div>

							<div className="space-y-2">
								<Label htmlFor="expiration_date">Data de Expiração</Label>
								<Input
									id="expiration_date"
									type="date"
									value={formData.expiration_date}
									onChange={(e) => setFormData({ ...formData, expiration_date: e.target.value })}
								/>
							</div>

							<div className="space-y-2 md:col-span-2">
								<Label htmlFor="issuer">Emissor</Label>
								<Input
									id="issuer"
									value={formData.issuer}
									onChange={(e) => setFormData({ ...formData, issuer: e.target.value })}
									placeholder="Ex: Detran-MG, Receita Federal, etc."
								/>
							</div>

							<div className="space-y-2 md:col-span-2">
								<Label htmlFor="description">Descrição</Label>
								<Textarea
									id="description"
									value={formData.description}
									onChange={(e) => setFormData({ ...formData, description: e.target.value })}
									placeholder="Descrição do documento..."
									rows={3}
								/>
							</div>

							<div className="space-y-2 md:col-span-2">
								<Label htmlFor="notes">Observações</Label>
								<Textarea
									id="notes"
									value={formData.notes}
									onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
									placeholder="Observações adicionais..."
									rows={3}
								/>
							</div>
						</div>

						<div className="flex gap-2 justify-end pt-4">
							<Button type="button" variant="outline" onClick={onClose}>
								Cancelar
							</Button>
							<Button type="submit" disabled={loading} className="gap-2">
								<Save className="w-4 h-4" />
								{loading ? "Salvando..." : "Salvar Documento"}
							</Button>
						</div>
					</form>
				</CardContent>
			</Card>
		</div>
	);
}
