import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
	MessageSquare,
	Mail,
	Phone,
	UserCheck,
	Lightbulb,
	Send,
	CheckCircle2,
	Clock,
	AlertCircle,
	Archive,
	Sparkles,
} from "lucide-react";
import { ClientORM, type ClientModel } from "@/components/data/orm/orm_client";
import { DemandORM, type DemandModel } from "@/components/data/orm/orm_demand";
import {
	InteractionORM,
	type InteractionModel,
	InteractionInteractionType,
	InteractionPriority,
	InteractionStatus,
} from "@/components/data/orm/orm_interaction";

/**
 * Configurações dos tipos de interação
 */
const INTERACTION_CONFIG = {
	[InteractionInteractionType.Unspecified]: { icon: MessageSquare, color: "text-gray-600", bg: "bg-gray-100", label: "Não especificado" },
	[InteractionInteractionType.WhatsApp]: { icon: MessageSquare, color: "text-green-600", bg: "bg-green-100", label: "WhatsApp" },
	[InteractionInteractionType.Email]: { icon: Mail, color: "text-blue-600", bg: "bg-blue-100", label: "E-mail" },
	[InteractionInteractionType.InPerson]: { icon: UserCheck, color: "text-purple-600", bg: "bg-purple-100", label: "Presencial" },
	[InteractionInteractionType.Phone]: { icon: Phone, color: "text-orange-600", bg: "bg-orange-100", label: "Telefone" },
	[InteractionInteractionType.System]: { icon: Clock, color: "text-gray-600", bg: "bg-gray-100", label: "Sistema" },
};

const PRIORITY_LABELS = {
	[InteractionPriority.Unspecified]: "Não especificada",
	[InteractionPriority.Low]: "Baixa",
	[InteractionPriority.Normal]: "Normal",
	[InteractionPriority.High]: "Alta",
	[InteractionPriority.Urgent]: "Urgente",
};

const STATUS_LABELS = {
	[InteractionStatus.Unspecified]: "Não especificado",
	[InteractionStatus.Pending]: "Pendente",
	[InteractionStatus.InProgress]: "Em Andamento",
	[InteractionStatus.Resolved]: "Resolvida",
	[InteractionStatus.Archived]: "Arquivada",
};

/**
 * IA de triagem inteligente - analisa a descrição e sugere ações
 */
function intelligentTriage(subject: string, description: string): string {
	const text = `${subject} ${description}`.toLowerCase();

	if (text.includes("isenção") || text.includes("isencao") || text.includes("ipi") || text.includes("icms")) {
		if (text.includes("taxista") || text.includes("táxi") || text.includes("taxi")) {
			return "Criar workflow de Isenção IPI/ICMS para Taxista. Solicitar: CNH categoria B, comprovante de atividade e documentos pessoais.";
		}
		if (text.includes("pcd") || text.includes("deficiente") || text.includes("deficiência")) {
			return "Criar workflow de Isenção IPI/ICMS para PCD. Solicitar: laudo médico atualizado, documentos pessoais e comprovante de renda.";
		}
		return "Processo de isenção fiscal detectado. Verificar tipo específico e documentação necessária.";
	}

	if (text.includes("receita") || text.includes("rfb") || text.includes("imposto de renda")) {
		return "Processo relacionado à Receita Federal. Criar workflow de Processo RFB. Analisar notificação e prazos.";
	}

	if (text.includes("inss") || text.includes("previdência") || text.includes("aposentadoria") || text.includes("benefício")) {
		return "Processo previdenciário identificado. Criar workflow de Processo INSS. Solicitar documentação previdenciária completa.";
	}

	if (text.includes("parcelamento") || text.includes("débito") || text.includes("dívida")) {
		return "Solicitação de parcelamento detectada. Analisar débitos e criar plano de parcelamento adequado.";
	}

	if (text.includes("documento") || text.includes("certidão") || text.includes("comprovante")) {
		return "Solicitação de documentos. Verificar tipo específico e prazo de entrega.";
	}

	if (text.includes("urgente") || text.includes("prazo") || text.includes("vencimento")) {
		return "⚠️ URGENTE - Demanda com prazo crítico identificada. Priorizar atendimento e verificar prazos legais.";
	}

	return "Analisar demanda e classificar adequadamente. Solicitar mais informações se necessário.";
}

/**
 * Determina prioridade automaticamente baseada nas palavras-chave
 */
function determinePriority(subject: string, description: string): InteractionPriority {
	const text = `${subject} ${description}`.toLowerCase();

	if (text.includes("urgente") || text.includes("prazo") || text.includes("vencimento") || text.includes("hoje")) {
		return InteractionPriority.Urgent;
	}

	if (text.includes("importante") || text.includes("necessário") || text.includes("preciso")) {
		return InteractionPriority.High;
	}

	if (text.includes("dúvida") || text.includes("duvida") || text.includes("informação")) {
		return InteractionPriority.Normal;
	}

	return InteractionPriority.Normal;
}

export function InteractionManager() {
	const [interactions, setInteractions] = React.useState<InteractionModel[]>([]);
	const [clients, setClients] = React.useState<ClientModel[]>([]);
	const [demands, setDemands] = React.useState<DemandModel[]>([]);
	const [loading, setLoading] = React.useState(true);
	const [showNewForm, setShowNewForm] = React.useState(false);

	// Formulário de nova interação
	const [formData, setFormData] = React.useState({
		client_id: "",
		demand_id: "",
		interaction_type: InteractionInteractionType.WhatsApp,
		subject: "",
		description: "",
		priority: InteractionPriority.Normal,
	});

	const [aiSuggestion, setAiSuggestion] = React.useState("");

	const clientORM = React.useMemo(() => ClientORM.getInstance(), []);
	const demandORM = React.useMemo(() => DemandORM.getInstance(), []);
	const interactionORM = React.useMemo(() => InteractionORM.getInstance(), []);

	React.useEffect(() => {
		loadData();
	}, []);

	const loadData = async () => {
		try {
			setLoading(true);
			const [allClients, allDemands, allInteractions] = await Promise.all([
				clientORM.getAllClient(),
				demandORM.getAllDemand(),
				interactionORM.getAllInteraction(),
			]);

			setClients(allClients);
			setDemands(allDemands);
			setInteractions(allInteractions);
		} catch (error) {
			console.error("Erro ao carregar interações:", error);
		} finally {
			setLoading(false);
		}
	};

	const handleAnalyze = () => {
		const suggestion = intelligentTriage(formData.subject, formData.description);
		const priority = determinePriority(formData.subject, formData.description);
		setAiSuggestion(suggestion);
		setFormData({ ...formData, priority });
	};

	const handleSubmit = async () => {
		if (!formData.client_id || !formData.subject || !formData.description) {
			alert("Preencha todos os campos obrigatórios");
			return;
		}

		try {
			const newInteraction = await interactionORM.insertInteraction([
				{
					client_id: formData.client_id,
					demand_id: formData.demand_id || null,
					interaction_type: formData.interaction_type,
					subject: formData.subject,
					description: formData.description,
					priority: formData.priority,
					status: InteractionStatus.Pending,
					suggested_action: aiSuggestion || null,
					resolved_at: null,
				} as InteractionModel,
			]);

			setInteractions([...newInteraction, ...interactions]);
			setShowNewForm(false);
			setFormData({
				client_id: "",
				demand_id: "",
				interaction_type: InteractionInteractionType.WhatsApp,
				subject: "",
				description: "",
				priority: InteractionPriority.Normal,
			});
			setAiSuggestion("");
			alert("Interação registrada com sucesso!");
		} catch (error) {
			console.error("Erro ao salvar interação:", error);
			alert("Erro ao salvar interação. Verifique o console.");
		}
	};

	const handleStartAttendance = async (interaction: InteractionModel) => {
		try {
			const updatedInteraction = {
				...interaction,
				status: InteractionStatus.InProgress,
			};

			await interactionORM.setInteractionById(interaction.id, updatedInteraction);

			setInteractions(
				interactions.map((i) =>
					i.id === interaction.id ? updatedInteraction : i
				)
			);
			alert("Atendimento iniciado com sucesso!");
		} catch (error) {
			console.error("Erro ao iniciar atendimento:", error);
			alert("Erro ao iniciar atendimento. Verifique o console.");
		}
	};

	const handleCreateDemand = (interaction: InteractionModel) => {
		alert(
			`Criar demanda para:\n\n` +
			`Cliente: ${clients.find((c) => c.id === interaction.client_id)?.full_name}\n` +
			`Assunto: ${interaction.subject}\n\n` +
			`Em produção, isso abriria o formulário de criação de demanda ` +
			`com os dados desta interação pré-preenchidos.`
		);
	};

	const handleMarkAsResolved = async (interaction: InteractionModel) => {
		try {
			const updatedInteraction = {
				...interaction,
				status: InteractionStatus.Resolved,
				resolved_at: new Date().toISOString(),
			};

			await interactionORM.setInteractionById(interaction.id, updatedInteraction);

			setInteractions(
				interactions.map((i) =>
					i.id === interaction.id ? updatedInteraction : i
				)
			);
			alert("Interação marcada como resolvida!");
		} catch (error) {
			console.error("Erro ao marcar como resolvida:", error);
			alert("Erro ao marcar como resolvida. Verifique o console.");
		}
	};

	const pendingInteractions = interactions.filter((i) => i.status === InteractionStatus.Pending);
	const inProgressInteractions = interactions.filter((i) => i.status === InteractionStatus.InProgress);

	return (
		<div className="space-y-6">
			<div className="flex items-center justify-between">
				<div>
					<h2 className="text-3xl font-bold text-gray-900">Módulo de Interações</h2>
					<p className="text-sm text-gray-600 mt-1">
						Gestão de interações com clientes e triagem inteligente de demandas
					</p>
				</div>
				<Button onClick={() => setShowNewForm(!showNewForm)}>
					<Send className="h-4 w-4 mr-2" />
					Nova Interação
				</Button>
			</div>

			{/* Resumo de Interações */}
			<div className="grid grid-cols-1 md:grid-cols-4 gap-4">
				<Card>
					<CardHeader className="pb-2">
						<CardTitle className="text-sm font-medium text-gray-600">Pendentes</CardTitle>
					</CardHeader>
					<CardContent>
						<div className="text-2xl font-bold">{pendingInteractions.length}</div>
						<p className="text-xs text-gray-500 mt-1">Aguardando atendimento</p>
					</CardContent>
				</Card>

				<Card>
					<CardHeader className="pb-2">
						<CardTitle className="text-sm font-medium text-gray-600">Em Andamento</CardTitle>
					</CardHeader>
					<CardContent>
						<div className="text-2xl font-bold">{inProgressInteractions.length}</div>
						<p className="text-xs text-gray-500 mt-1">Sendo processadas</p>
					</CardContent>
				</Card>

				<Card>
					<CardHeader className="pb-2">
						<CardTitle className="text-sm font-medium text-gray-600">Total de Interações</CardTitle>
					</CardHeader>
					<CardContent>
						<div className="text-2xl font-bold">{interactions.length}</div>
						<p className="text-xs text-gray-500 mt-1">Todos os registros</p>
					</CardContent>
				</Card>

				<Card>
					<CardHeader className="pb-2">
						<CardTitle className="text-sm font-medium text-gray-600">IA Ativa</CardTitle>
					</CardHeader>
					<CardContent>
						<div className="flex items-center gap-2">
							<Sparkles className="h-5 w-5 text-purple-600" />
							<span className="text-sm font-medium">Triagem Inteligente</span>
						</div>
						<p className="text-xs text-gray-500 mt-1">Sugestões automáticas</p>
					</CardContent>
				</Card>
			</div>

			{/* Formulário de Nova Interação */}
			{showNewForm && (
				<Card>
					<CardHeader>
						<CardTitle className="flex items-center gap-2">
							<Sparkles className="h-5 w-5 text-purple-600" />
							Nova Interação com Triagem Inteligente
						</CardTitle>
						<CardDescription>
							A IA irá analisar sua descrição e sugerir ações automaticamente
						</CardDescription>
					</CardHeader>
					<CardContent className="space-y-4">
						<div className="grid grid-cols-2 gap-4">
							<div className="space-y-2">
								<Label htmlFor="client">Cliente *</Label>
								<Select
									value={formData.client_id}
									onValueChange={(value) => setFormData({ ...formData, client_id: value })}
								>
									<SelectTrigger id="client">
										<SelectValue placeholder="Selecione o cliente" />
									</SelectTrigger>
									<SelectContent>
										{clients.map((client) => (
											<SelectItem key={client.id} value={client.id}>
												{client.full_name}
											</SelectItem>
										))}
									</SelectContent>
								</Select>
							</div>

							<div className="space-y-2">
								<Label htmlFor="type">Canal de Atendimento *</Label>
								<Select
									value={formData.interaction_type.toString()}
									onValueChange={(value) =>
										setFormData({ ...formData, interaction_type: parseInt(value) as InteractionInteractionType })
									}
								>
									<SelectTrigger id="type">
										<SelectValue />
									</SelectTrigger>
									<SelectContent>
										{Object.entries(INTERACTION_CONFIG).map(([key, config]) => (
											<SelectItem key={key} value={key}>
												{config.label}
											</SelectItem>
										))}
									</SelectContent>
								</Select>
							</div>
						</div>

						<div className="space-y-2">
							<Label htmlFor="subject">Assunto *</Label>
							<Input
								id="subject"
								value={formData.subject}
								onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
								placeholder="Ex: Dúvida sobre isenção IPI"
							/>
						</div>

						<div className="space-y-2">
							<Label htmlFor="description">Descrição da Demanda *</Label>
							<Textarea
								id="description"
								value={formData.description}
								onChange={(e) => setFormData({ ...formData, description: e.target.value })}
								placeholder="Descreva a demanda do cliente em detalhes..."
								rows={4}
							/>
						</div>

						<Button onClick={handleAnalyze} variant="outline" className="w-full">
							<Sparkles className="h-4 w-4 mr-2" />
							Analisar com IA
						</Button>

						{aiSuggestion && (
							<Alert className="bg-purple-50 border-purple-200">
								<Lightbulb className="h-4 w-4 text-purple-600" />
								<AlertDescription className="text-purple-900">
									<strong className="block mb-1">Sugestão Inteligente:</strong>
									{aiSuggestion}
								</AlertDescription>
							</Alert>
						)}

						<div className="flex gap-2">
							<Button onClick={handleSubmit} className="flex-1" disabled={!formData.client_id || !formData.subject}>
								<Send className="h-4 w-4 mr-2" />
								Registrar Interação
							</Button>
							<Button onClick={() => setShowNewForm(false)} variant="outline" className="flex-1">
								Cancelar
							</Button>
						</div>
					</CardContent>
				</Card>
			)}

			{/* Lista de Interações */}
			<div className="space-y-4">
				{loading ? (
					<Card>
						<CardContent className="p-8 text-center text-gray-500">
							Carregando interações...
						</CardContent>
					</Card>
				) : interactions.length === 0 ? (
					<Card>
						<CardContent className="p-8 text-center text-gray-500">
							Nenhuma interação registrada. Clique em "Nova Interação" para começar.
						</CardContent>
					</Card>
				) : (
					interactions.map((interaction) => {
						const client = clients.find((c) => c.id === interaction.client_id);
						const demand = interaction.demand_id
							? demands.find((d) => d.id === interaction.demand_id)
							: undefined;
						const config = INTERACTION_CONFIG[interaction.interaction_type];
						const Icon = config?.icon || MessageSquare;

						let StatusIcon = Clock;
						let statusColor = "text-gray-600";

						switch (interaction.status) {
							case InteractionStatus.Pending:
								StatusIcon = Clock;
								statusColor = "text-yellow-600";
								break;
							case InteractionStatus.InProgress:
								StatusIcon = AlertCircle;
								statusColor = "text-blue-600";
								break;
							case InteractionStatus.Resolved:
								StatusIcon = CheckCircle2;
								statusColor = "text-green-600";
								break;
							case InteractionStatus.Archived:
								StatusIcon = Archive;
								statusColor = "text-gray-600";
								break;
						}

						return (
							<Card key={interaction.id}>
								<CardHeader>
									<div className="flex items-start justify-between">
										<div className="flex items-center gap-3">
											<div className={`p-2 rounded-lg ${config?.bg || "bg-gray-100"}`}>
												<Icon className={`h-5 w-5 ${config?.color || "text-gray-600"}`} />
											</div>
											<div>
												<CardTitle className="text-lg">{interaction.subject}</CardTitle>
												<CardDescription>
													{client?.full_name || "Cliente não identificado"}
													{demand && ` • Processo: ${demand.demand_number}`}
												</CardDescription>
											</div>
										</div>
										<div className="flex gap-2">
											<Badge
												variant={
													interaction.priority === InteractionPriority.Urgent
														? "destructive"
														: "outline"
												}
											>
												{PRIORITY_LABELS[interaction.priority] || "Normal"}
											</Badge>
											<Badge variant="outline">
												<StatusIcon className={`h-3 w-3 mr-1 ${statusColor}`} />
												{STATUS_LABELS[interaction.status] || "Pendente"}
											</Badge>
										</div>
									</div>
								</CardHeader>
								<CardContent className="space-y-4">
									<div>
										<p className="text-sm text-gray-700">{interaction.description}</p>
									</div>

									{interaction.suggested_action && (
										<Alert className="bg-purple-50 border-purple-200">
											<Lightbulb className="h-4 w-4 text-purple-600" />
											<AlertDescription className="text-purple-900 text-sm">
												<strong>Sugestão IA:</strong> {interaction.suggested_action}
											</AlertDescription>
										</Alert>
									)}

									<div className="flex gap-2">
										<Button
											size="sm"
											variant="outline"
											className="flex-1"
											onClick={() => handleStartAttendance(interaction)}
											disabled={interaction.status !== InteractionStatus.Pending}
										>
											Iniciar Atendimento
										</Button>
										<Button
											size="sm"
											variant="outline"
											className="flex-1"
											onClick={() => handleCreateDemand(interaction)}
										>
											Criar Demanda
										</Button>
										<Button
											size="sm"
											variant="outline"
											className="flex-1"
											onClick={() => handleMarkAsResolved(interaction)}
											disabled={interaction.status === InteractionStatus.Resolved}
										>
											Marcar como Resolvida
										</Button>
									</div>
								</CardContent>
							</Card>
						);
					})
				)}
			</div>
		</div>
	);
}
