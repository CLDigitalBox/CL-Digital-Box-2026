import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
	Calendar,
	DollarSign,
	AlertCircle,
	CheckCircle2,
	XCircle,
	Download,
	Bell,
	TrendingUp,
	Building2,
	FileText,
} from "lucide-react";
import { ClientORM, type ClientModel } from "@/components/data/orm/orm_client";

/**
 * Tipos de parcelamento disponíveis
 */
export enum InstallmentType {
	RFB = "RFB",
	PGFN = "PGFN",
	SEFMG = "SEF-MG",
	Municipal = "Municipal",
	Outros = "Outros",
}

export enum InstallmentStatus {
	Active = "Ativo",
	Delayed = "Atrasado",
	Paid = "Quitado",
	Cancelled = "Cancelado",
}

/**
 * Interface de Parcelamento (usando estrutura de dados do Client para armazenamento)
 */
interface InstallmentModel {
	id: string;
	client_id: string;
	installment_type: InstallmentType;
	total_amount: number;
	installments_count: number;
	installments_paid: number;
	next_due_date: string;
	status: InstallmentStatus;
	alert_enabled: boolean;
	created_at: string;
}

/**
 * Configurações dos tipos de parcelamento
 */
const INSTALLMENT_CONFIG = {
	[InstallmentType.RFB]: {
		name: "Receita Federal (RFB)",
		icon: Building2,
		color: "bg-blue-600",
		maxInstallments: 60,
		guideTemplate: "DARF",
	},
	[InstallmentType.PGFN]: {
		name: "Procuradoria Geral da Fazenda Nacional",
		icon: Building2,
		color: "bg-purple-600",
		maxInstallments: 84,
		guideTemplate: "DARF",
	},
	[InstallmentType.SEFMG]: {
		name: "Secretaria da Fazenda de MG",
		icon: Building2,
		color: "bg-green-600",
		maxInstallments: 48,
		guideTemplate: "DARE-MG",
	},
	[InstallmentType.Municipal]: {
		name: "Prefeitura Municipal",
		icon: Building2,
		color: "bg-orange-600",
		maxInstallments: 36,
		guideTemplate: "DAM",
	},
	[InstallmentType.Outros]: {
		name: "Outros Parcelamentos",
		icon: FileText,
		color: "bg-gray-600",
		maxInstallments: 120,
		guideTemplate: "GUIA",
	},
};

/**
 * Calcula dias até o vencimento
 */
function getDaysUntilDue(dueDate: string): number {
	const today = new Date();
	const due = new Date(dueDate);
	const diffTime = due.getTime() - today.getTime();
	return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
}

/**
 * Formata valor em moeda brasileira
 */
function formatCurrency(value: number): string {
	return new Intl.NumberFormat("pt-BR", {
		style: "currency",
		currency: "BRL",
	}).format(value);
}

/**
 * Formata data para exibição
 */
function formatDate(dateString: string): string {
	const date = new Date(dateString);
	return new Intl.DateTimeFormat("pt-BR").format(date);
}

/**
 * Gera guia de pagamento em PDF (simulado)
 */
function generatePaymentGuide(installment: InstallmentModel, client: ClientModel | undefined): void {
	const config = INSTALLMENT_CONFIG[installment.installment_type];
	const installmentValue = installment.total_amount / installment.installments_count;

	// Simulação de geração de guia
	const guideData = {
		type: config.guideTemplate,
		beneficiary: config.name,
		payer: client?.full_name || "Cliente não identificado",
		cpfCnpj: client?.cpf_cnpj || "",
		value: formatCurrency(installmentValue),
		dueDate: formatDate(installment.next_due_date),
		installment: `${installment.installments_paid + 1}/${installment.installments_count}`,
		barcode: `${Math.random().toString().slice(2, 50)}`,
	};

	console.log("Gerando guia de pagamento:", guideData);
	alert(
		`Guia ${config.guideTemplate} gerada!\n\n` +
		`Beneficiário: ${guideData.beneficiary}\n` +
		`Pagador: ${guideData.payer}\n` +
		`CPF/CNPJ: ${guideData.cpfCnpj}\n` +
		`Valor: ${guideData.value}\n` +
		`Vencimento: ${guideData.dueDate}\n` +
		`Parcela: ${guideData.installment}\n\n` +
		`Em produção, este botão geraria um PDF com código de barras.`
	);
}

/**
 * Registra o pagamento de uma parcela
 */
function registerPayment(installment: InstallmentModel): void {
	const config = INSTALLMENT_CONFIG[installment.installment_type];
	const newPaidCount = installment.installments_paid + 1;
	const isComplete = newPaidCount >= installment.installments_count;

	alert(
		`Registrar Pagamento - ${config.guideTemplate}\n\n` +
		`Parcela: ${newPaidCount}/${installment.installments_count}\n` +
		`Valor: ${formatCurrency(installment.total_amount / installment.installments_count)}\n\n` +
		`${isComplete ? "🎉 Esta é a última parcela! Parcelamento será quitado." : `Próxima parcela: ${newPaidCount + 1}/${installment.installments_count}`}\n\n` +
		`Em produção, este botão:\n` +
		`1. Atualizaria o contador de parcelas pagas\n` +
		`2. Atualizaria a próxima data de vencimento\n` +
		`3. Geraria recibo de pagamento\n` +
		`4. Enviaria notificação ao cliente`
	);
}

export function InstallmentManager() {
	const [installments, setInstallments] = React.useState<InstallmentModel[]>([]);
	const [clients, setClients] = React.useState<Map<string, ClientModel>>(new Map());
	const [loading, setLoading] = React.useState(true);

	const clientORM = React.useMemo(() => ClientORM.getInstance(), []);

	React.useEffect(() => {
		loadInstallments();
	}, []);

	const loadInstallments = async () => {
		try {
			setLoading(true);
			const allClients = await clientORM.getAllClient();

			// Criar mapa de clientes
			const clientMap = new Map<string, ClientModel>();
			allClients.forEach((client: ClientModel) => {
				clientMap.set(client.id, client);
			});
			setClients(clientMap);

			// Dados de exemplo de parcelamentos
			// Em produção, estes dados viriam de um ORM dedicado
			const mockInstallments: InstallmentModel[] = [
				{
					id: "1",
					client_id: allClients[0]?.id || "unknown",
					installment_type: InstallmentType.RFB,
					total_amount: 12000,
					installments_count: 12,
					installments_paid: 3,
					next_due_date: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString(),
					status: InstallmentStatus.Active,
					alert_enabled: true,
					created_at: new Date().toISOString(),
				},
				{
					id: "2",
					client_id: allClients[1]?.id || "unknown",
					installment_type: InstallmentType.SEFMG,
					total_amount: 8400,
					installments_count: 24,
					installments_paid: 18,
					next_due_date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
					status: InstallmentStatus.Delayed,
					alert_enabled: true,
					created_at: new Date().toISOString(),
				},
			];

			setInstallments(mockInstallments);
		} catch (error) {
			console.error("Erro ao carregar parcelamentos:", error);
		} finally {
			setLoading(false);
		}
	};

	const activeInstallments = installments.filter(
		(i) => i.status === InstallmentStatus.Active || i.status === InstallmentStatus.Delayed
	);
	const delayedInstallments = installments.filter((i) => i.status === InstallmentStatus.Delayed);

	return (
		<div className="space-y-6">
			<div>
				<h2 className="text-3xl font-bold text-gray-900">Módulo de Parcelamentos</h2>
				<p className="text-sm text-gray-600 mt-1">
					Controle de parcelamentos fiscais com alertas automáticos e geração de guias
				</p>
			</div>

			{/* Alertas de Vencimentos */}
			{delayedInstallments.length > 0 && (
				<Alert variant="destructive">
					<AlertCircle className="h-4 w-4" />
					<AlertTitle>Atenção! Parcelamentos em Atraso</AlertTitle>
					<AlertDescription>
						Você possui {delayedInstallments.length} parcelamento(s) com vencimento atrasado.
						Regularize o quanto antes para evitar multas e cancelamento.
					</AlertDescription>
				</Alert>
			)}

			{/* Resumo de Parcelamentos */}
			<div className="grid grid-cols-1 md:grid-cols-4 gap-4">
				<Card>
					<CardHeader className="pb-2">
						<CardTitle className="text-sm font-medium text-gray-600">
							Parcelamentos Ativos
						</CardTitle>
					</CardHeader>
					<CardContent>
						<div className="text-2xl font-bold">{activeInstallments.length}</div>
						<p className="text-xs text-gray-500 mt-1">Em andamento</p>
					</CardContent>
				</Card>

				<Card>
					<CardHeader className="pb-2">
						<CardTitle className="text-sm font-medium text-gray-600">
							Parcelas Pagas
						</CardTitle>
					</CardHeader>
					<CardContent>
						<div className="text-2xl font-bold">
							{installments.reduce((acc, i) => acc + i.installments_paid, 0)}
						</div>
						<p className="text-xs text-gray-500 mt-1">Total quitado</p>
					</CardContent>
				</Card>

				<Card>
					<CardHeader className="pb-2">
						<CardTitle className="text-sm font-medium text-gray-600">
							Valor Total
						</CardTitle>
					</CardHeader>
					<CardContent>
						<div className="text-2xl font-bold">
							{formatCurrency(installments.reduce((acc, i) => acc + i.total_amount, 0))}
						</div>
						<p className="text-xs text-gray-500 mt-1">Soma de parcelamentos</p>
					</CardContent>
				</Card>

				<Card>
					<CardHeader className="pb-2">
						<CardTitle className="text-sm font-medium text-gray-600">
							Em Atraso
						</CardTitle>
					</CardHeader>
					<CardContent>
						<div className="text-2xl font-bold text-red-600">
							{delayedInstallments.length}
						</div>
						<p className="text-xs text-gray-500 mt-1">Requer atenção</p>
					</CardContent>
				</Card>
			</div>

			{/* Lista de Parcelamentos */}
			<div className="space-y-4">
				{loading ? (
					<Card>
						<CardContent className="p-8 text-center text-gray-500">
							Carregando parcelamentos...
						</CardContent>
					</Card>
				) : installments.length === 0 ? (
					<Card>
						<CardContent className="p-8 text-center text-gray-500">
							Nenhum parcelamento cadastrado.
						</CardContent>
					</Card>
				) : (
					installments.map((installment) => {
						const client = clients.get(installment.client_id);
						const config = INSTALLMENT_CONFIG[installment.installment_type];
						const Icon = config.icon;
						const progress = (installment.installments_paid / installment.installments_count) * 100;
						const installmentValue = installment.total_amount / installment.installments_count;
						const daysUntilDue = getDaysUntilDue(installment.next_due_date);
						const isDelayed = daysUntilDue < 0;
						const isNearDue = daysUntilDue >= 0 && daysUntilDue <= 7;

						return (
							<Card key={installment.id}>
								<CardHeader>
									<div className="flex items-start justify-between">
										<div className="flex items-center gap-3">
											<div className={`p-2 rounded-lg ${config.color} text-white`}>
												<Icon className="h-5 w-5" />
											</div>
											<div>
												<CardTitle className="text-lg">{config.name}</CardTitle>
												<CardDescription>
													{client?.full_name || "Cliente não identificado"}
												</CardDescription>
											</div>
										</div>
										<div className="flex gap-2">
											{installment.alert_enabled && (
												<Badge variant="outline" className="gap-1">
													<Bell className="h-3 w-3" />
													Alertas ativos
												</Badge>
											)}
											<Badge
												variant={
													installment.status === InstallmentStatus.Active
														? "default"
														: installment.status === InstallmentStatus.Delayed
														? "destructive"
														: installment.status === InstallmentStatus.Paid
														? "secondary"
														: "outline"
												}
											>
												{installment.status === InstallmentStatus.Active && (
													<TrendingUp className="h-3 w-3 mr-1" />
												)}
												{installment.status === InstallmentStatus.Delayed && (
													<AlertCircle className="h-3 w-3 mr-1" />
												)}
												{installment.status === InstallmentStatus.Paid && (
													<CheckCircle2 className="h-3 w-3 mr-1" />
												)}
												{installment.status === InstallmentStatus.Cancelled && (
													<XCircle className="h-3 w-3 mr-1" />
												)}
												{installment.status}
											</Badge>
										</div>
									</div>
								</CardHeader>
								<CardContent className="space-y-4">
									<div className="grid grid-cols-2 md:grid-cols-4 gap-4">
										<div>
											<p className="text-xs text-gray-500 mb-1">Valor Total</p>
											<p className="text-sm font-medium">
												{formatCurrency(installment.total_amount)}
											</p>
										</div>
										<div>
											<p className="text-xs text-gray-500 mb-1">Valor da Parcela</p>
											<p className="text-sm font-medium">
												{formatCurrency(installmentValue)}
											</p>
										</div>
										<div>
											<p className="text-xs text-gray-500 mb-1">Próximo Vencimento</p>
											<p
												className={`text-sm font-medium ${
													isDelayed
														? "text-red-600"
														: isNearDue
														? "text-yellow-600"
														: ""
												}`}
											>
												{formatDate(installment.next_due_date)}
												{isDelayed && (
													<span className="text-xs ml-1">(Atrasado)</span>
												)}
												{isNearDue && (
													<span className="text-xs ml-1">({daysUntilDue} dias)</span>
												)}
											</p>
										</div>
										<div>
											<p className="text-xs text-gray-500 mb-1">Parcelas</p>
											<p className="text-sm font-medium">
												{installment.installments_paid} / {installment.installments_count}
											</p>
										</div>
									</div>

									<div>
										<div className="flex items-center justify-between text-sm mb-2">
											<span className="text-gray-600">Progresso do pagamento</span>
											<span className="font-medium">{progress.toFixed(1)}%</span>
										</div>
										<Progress value={progress} className="h-2" />
									</div>

									{(isDelayed || isNearDue) && (
										<Alert variant={isDelayed ? "destructive" : "default"}>
											<Calendar className="h-4 w-4" />
											<AlertDescription>
												{isDelayed
													? `Parcela vencida há ${Math.abs(daysUntilDue)} dia(s). Regularize o quanto antes!`
													: `Parcela vence em ${daysUntilDue} dia(s). Não se esqueça de pagar!`}
											</AlertDescription>
										</Alert>
									)}

									<div className="flex gap-2 pt-2">
										<Button
											size="sm"
											variant="outline"
											className="flex-1"
											onClick={() => generatePaymentGuide(installment, client)}
										>
											<Download className="h-4 w-4 mr-2" />
											Gerar Guia {config.guideTemplate}
										</Button>
										<Button
											size="sm"
											variant="outline"
											className="flex-1"
											onClick={() => registerPayment(installment)}
										>
											<DollarSign className="h-4 w-4 mr-2" />
											Registrar Pagamento
										</Button>
									</div>
								</CardContent>
							</Card>
						);
					})
				)}
			</div>
		</div>
	);
}
