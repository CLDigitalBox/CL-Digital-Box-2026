import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
	Mail,
	MessageSquare,
	Send,
	CheckCircle2,
	Clock,
	XCircle,
	Settings,
	Zap,
} from "lucide-react";
import { ClientORM, type ClientModel } from "@/components/data/orm/orm_client";
import {
	NotificationORM,
	type NotificationModel,
	NotificationType,
	NotificationStatus,
} from "@/components/data/orm/orm_notification";
import { sendEmail as sendEmailAPI, createNotificationEmailTemplate } from "@/lib/email";

/**
 * Configuração de notificações automáticas
 */
interface NotificationSettings {
	emailEnabled: boolean;
	whatsappEnabled: boolean;
	notifyDeadlines: boolean;
	notifyNewDemands: boolean;
	notifyInstallments: boolean;
	notifyDocuments: boolean;
	deadlineWarningDays: number;
}

/**
 * Templates de mensagens
 */
const MESSAGE_TEMPLATES = {
	deadline_warning: {
		subject: "Lembrete: Prazo próximo do vencimento",
		email: `Olá {{client_name}},\n\nEste é um lembrete de que o prazo para {{demand_description}} está próximo do vencimento.\n\nData de vencimento: {{deadline}}\n\nPor favor, tome as providências necessárias.\n\nAtenciosamente,\nCL Assessoria e Consultoria Digital`,
		whatsapp: `Olá {{client_name}}! 👋\n\n⏰ Lembrete: O prazo para {{demand_description}} vence em {{days_remaining}} dias ({{deadline}}).\n\nQualquer dúvida, estamos à disposição!`,
	},
	installment_due: {
		subject: "Vencimento de Parcela",
		email: `Olá {{client_name}},\n\nInformamos que a parcela {{installment_number}} do seu parcelamento vence em {{due_date}}.\n\nValor: {{amount}}\n\nCódigo de barras disponível em nosso sistema.\n\nAtenciosamente,\nCL Assessoria e Consultoria Digital`,
		whatsapp: `Olá {{client_name}}! 💰\n\nSua parcela {{installment_number}} vence em {{due_date}}.\nValor: {{amount}}\n\nAcesse nosso sistema para gerar o boleto!`,
	},
	demand_created: {
		subject: "Nova Demanda Criada",
		email: `Olá {{client_name}},\n\nSua demanda foi criada com sucesso!\n\nNúmero: {{demand_number}}\nTipo: {{demand_type}}\n\nAcompanhe o andamento em nosso sistema.\n\nAtenciosamente,\nCL Assessoria e Consultoria Digital`,
		whatsapp: `Olá {{client_name}}! ✅\n\nSua demanda foi criada:\n📝 {{demand_number}}\n\nEm breve entraremos em contato!`,
	},
	document_request: {
		subject: "Solicitação de Documentos",
		email: `Olá {{client_name}},\n\nSolicitamos o envio dos seguintes documentos:\n\n{{document_list}}\n\nEnvie através do nosso sistema ou WhatsApp.\n\nAtenciosamente,\nCL Assessoria e Consultoria Digital`,
		whatsapp: `Olá {{client_name}}! 📄\n\nPrecisamos dos seguintes documentos:\n{{document_list}}\n\nPode enviar por aqui mesmo!`,
	},
};

const TYPE_LABELS = {
	[NotificationType.Unspecified]: "Não especificado",
	[NotificationType.Email]: "E-mail",
	[NotificationType.WhatsApp]: "WhatsApp",
};

const STATUS_LABELS = {
	[NotificationStatus.Unspecified]: "Não especificado",
	[NotificationStatus.Pending]: "Pendente",
	[NotificationStatus.Sent]: "Enviada",
	[NotificationStatus.Failed]: "Falhou",
	[NotificationStatus.Delivered]: "Entregue",
};

/**
 * Envia e-mail via Resend API
 */
async function sendEmail(
	to: string,
	subject: string,
	message: string,
	clientName: string
): Promise<{ success: boolean; error?: string }> {
	const emailHtml = createNotificationEmailTemplate(clientName, subject, message);

	const result = await sendEmailAPI({
		to,
		subject,
		html: emailHtml,
		text: message,
	});

	return result;
}

/**
 * Simula envio de WhatsApp
 * TODO: Implementar integração real com API do WhatsApp Business
 */
async function sendWhatsApp(
	to: string,
	message: string
): Promise<{ success: boolean; error?: string }> {
	return new Promise((resolve) => {
		setTimeout(() => {
			console.log("=== WHATSAPP ENVIADO (SIMULADO) ===");
			console.log("Para:", to);
			console.log("Mensagem:", message);
			console.log("===================================");

			// Simula sucesso
			resolve({ success: true });

			// TODO: Implementar chamada real com WhatsApp Business API
		}, 1500);
	});
}

export function NotificationCenter() {
	const [clients, setClients] = React.useState<ClientModel[]>([]);
	const [notifications, setNotifications] = React.useState<NotificationModel[]>([]);
	const [loading, setLoading] = React.useState(true);
	const [sending, setSending] = React.useState(false);

	// Configurações
	const [settings, setSettings] = React.useState<NotificationSettings>({
		emailEnabled: true,
		whatsappEnabled: true,
		notifyDeadlines: true,
		notifyNewDemands: true,
		notifyInstallments: true,
		notifyDocuments: true,
		deadlineWarningDays: 7,
	});

	// Formulário de nova notificação
	const [formData, setFormData] = React.useState({
		client_id: "",
		type: NotificationType.WhatsApp,
		template: "deadline_warning",
		subject: "",
		message: "",
	});

	const clientORM = React.useMemo(() => ClientORM.getInstance(), []);
	const notificationORM = React.useMemo(() => NotificationORM.getInstance(), []);

	React.useEffect(() => {
		loadData();
	}, []);

	const loadData = async () => {
		try {
			setLoading(true);
			const [allClients, allNotifications] = await Promise.all([
				clientORM.getAllClient(),
				notificationORM.getAllNotification(),
			]);

			setClients(allClients);
			setNotifications(allNotifications);
		} catch (error) {
			console.error("Erro ao carregar dados:", error);
		} finally {
			setLoading(false);
		}
	};

	const handleTemplateChange = (template: string) => {
		const templateData = MESSAGE_TEMPLATES[template as keyof typeof MESSAGE_TEMPLATES];
		if (templateData) {
			setFormData({
				...formData,
				template,
				subject: templateData.subject,
				message:
					formData.type === NotificationType.Email
						? templateData.email
						: templateData.whatsapp,
			});
		}
	};

	const handleSend = async () => {
		if (!formData.client_id || !formData.message) {
			alert("Preencha todos os campos obrigatórios");
			return;
		}

		const client = clients.find((c) => c.id === formData.client_id);
		if (!client) {
			alert("Cliente não encontrado");
			return;
		}

		setSending(true);

		try {
			let result;
			if (formData.type === NotificationType.Email) {
				const email = client.contact_info?.email || "";
				if (!email) {
					alert("Cliente não possui e-mail cadastrado");
					setSending(false);
					return;
				}
				result = await sendEmail(email, formData.subject, formData.message, client.full_name);
			} else {
				const phone = client.contact_info?.phone_primary || "";
				if (!phone) {
					alert("Cliente não possui telefone cadastrado");
					setSending(false);
					return;
				}
				result = await sendWhatsApp(phone, formData.message);
			}

			if (result.success) {
				// Salvar no banco
				const newNotification = await notificationORM.insertNotification([
					{
						client_id: formData.client_id,
						demand_id: null,
						type: formData.type,
						subject: formData.subject,
						message: formData.message,
						status: NotificationStatus.Sent,
						sent_at: new Date().toISOString(),
						delivered_at: null,
						error_message: null,
					} as NotificationModel,
				]);

				setNotifications([...newNotification, ...notifications]);
				alert(`${TYPE_LABELS[formData.type]} enviado com sucesso!`);

				// Resetar formulário
				setFormData({
					client_id: "",
					type: NotificationType.WhatsApp,
					template: "deadline_warning",
					subject: "",
					message: "",
				});
			}
		} catch (error) {
			// Salvar erro no banco
			await notificationORM.insertNotification([
				{
					client_id: formData.client_id,
					demand_id: null,
					type: formData.type,
					subject: formData.subject,
					message: formData.message,
					status: NotificationStatus.Failed,
					sent_at: new Date().toISOString(),
					delivered_at: null,
					error_message: (error as Error).message,
				} as NotificationModel,
			]);

			alert("Erro ao enviar notificação: " + (error as Error).message);
		} finally {
			setSending(false);
		}
	};

	const pendingNotifications = notifications.filter(
		(n) => n.status === NotificationStatus.Pending
	);
	const sentNotifications = notifications.filter((n) => n.status === NotificationStatus.Sent);
	const deliveredNotifications = notifications.filter(
		(n) => n.status === NotificationStatus.Delivered
	);

	return (
		<div className="space-y-6">
			<div>
				<h2 className="text-3xl font-bold text-gray-900">Central de Notificações</h2>
				<p className="text-sm text-gray-600 mt-1">
					Sistema automatizado de notificações por e-mail e WhatsApp
				</p>
			</div>

			{/* Resumo */}
			<div className="grid grid-cols-1 md:grid-cols-4 gap-4">
				<Card>
					<CardHeader className="pb-2">
						<CardTitle className="text-sm font-medium text-gray-600">Pendentes</CardTitle>
					</CardHeader>
					<CardContent>
						<div className="text-2xl font-bold">{pendingNotifications.length}</div>
					</CardContent>
				</Card>

				<Card>
					<CardHeader className="pb-2">
						<CardTitle className="text-sm font-medium text-gray-600">Enviadas</CardTitle>
					</CardHeader>
					<CardContent>
						<div className="text-2xl font-bold">{sentNotifications.length}</div>
					</CardContent>
				</Card>

				<Card>
					<CardHeader className="pb-2">
						<CardTitle className="text-sm font-medium text-gray-600">Entregues</CardTitle>
					</CardHeader>
					<CardContent>
						<div className="text-2xl font-bold">{deliveredNotifications.length}</div>
					</CardContent>
				</Card>

				<Card>
					<CardHeader className="pb-2">
						<CardTitle className="text-sm font-medium text-gray-600">Total</CardTitle>
					</CardHeader>
					<CardContent>
						<div className="text-2xl font-bold">{notifications.length}</div>
					</CardContent>
				</Card>
			</div>

			<Tabs defaultValue="send" className="w-full">
				<TabsList className="grid w-full grid-cols-3">
					<TabsTrigger value="send">
						<Send className="h-4 w-4 mr-2" />
						Enviar Notificação
					</TabsTrigger>
					<TabsTrigger value="history">
						<Clock className="h-4 w-4 mr-2" />
						Histórico
					</TabsTrigger>
					<TabsTrigger value="settings">
						<Settings className="h-4 w-4 mr-2" />
						Configurações
					</TabsTrigger>
				</TabsList>

				{/* Enviar Notificação */}
				<TabsContent value="send" className="mt-6">
					<Card>
						<CardHeader>
							<CardTitle>Nova Notificação</CardTitle>
							<CardDescription>
								Envie notificações personalizadas para seus clientes
							</CardDescription>
						</CardHeader>
						<CardContent className="space-y-4">
							<div className="grid grid-cols-2 gap-4">
								<div className="space-y-2">
									<Label htmlFor="client">Cliente *</Label>
									<Select
										value={formData.client_id}
										onValueChange={(value) => setFormData({ ...formData, client_id: value })}
									>
										<SelectTrigger id="client">
											<SelectValue placeholder="Selecione o cliente" />
										</SelectTrigger>
										<SelectContent>
											{clients.map((client) => (
												<SelectItem key={client.id} value={client.id}>
													{client.full_name}
												</SelectItem>
											))}
										</SelectContent>
									</Select>
								</div>

								<div className="space-y-2">
									<Label htmlFor="type">Canal *</Label>
									<Select
										value={formData.type.toString()}
										onValueChange={(value) =>
											setFormData({ ...formData, type: parseInt(value) as NotificationType })
										}
									>
										<SelectTrigger id="type">
											<SelectValue />
										</SelectTrigger>
										<SelectContent>
											<SelectItem value={NotificationType.WhatsApp.toString()}>
												<div className="flex items-center gap-2">
													<MessageSquare className="h-4 w-4" />
													WhatsApp
												</div>
											</SelectItem>
											<SelectItem value={NotificationType.Email.toString()}>
												<div className="flex items-center gap-2">
													<Mail className="h-4 w-4" />
													E-mail
												</div>
											</SelectItem>
										</SelectContent>
									</Select>
								</div>
							</div>

							<div className="space-y-2">
								<Label htmlFor="template">Template</Label>
								<Select
									value={formData.template}
									onValueChange={handleTemplateChange}
								>
									<SelectTrigger id="template">
										<SelectValue />
									</SelectTrigger>
									<SelectContent>
										<SelectItem value="deadline_warning">Lembrete de Prazo</SelectItem>
										<SelectItem value="installment_due">Vencimento de Parcela</SelectItem>
										<SelectItem value="demand_created">Nova Demanda</SelectItem>
										<SelectItem value="document_request">Solicitação de Documentos</SelectItem>
									</SelectContent>
								</Select>
							</div>

							{formData.type === NotificationType.Email && (
								<div className="space-y-2">
									<Label htmlFor="subject">Assunto *</Label>
									<Input
										id="subject"
										value={formData.subject}
										onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
										placeholder="Assunto do e-mail"
									/>
								</div>
							)}

							<div className="space-y-2">
								<Label htmlFor="message">Mensagem *</Label>
								<Textarea
									id="message"
									value={formData.message}
									onChange={(e) => setFormData({ ...formData, message: e.target.value })}
									placeholder="Digite sua mensagem aqui..."
									rows={6}
								/>
								<p className="text-xs text-gray-500">
									Use variáveis como {"{{client_name}}"}, {"{{demand_number}}"}, etc.
								</p>
							</div>

							<Button
								onClick={handleSend}
								disabled={!formData.client_id || !formData.message || sending}
								className="w-full"
								size="lg"
							>
								<Send className="h-4 w-4 mr-2" />
								{sending ? "Enviando..." : `Enviar ${TYPE_LABELS[formData.type]}`}
							</Button>
						</CardContent>
					</Card>
				</TabsContent>

				{/* Histórico */}
				<TabsContent value="history" className="mt-6 space-y-3">
					{notifications.length === 0 ? (
						<Card>
							<CardContent className="p-8 text-center text-gray-500">
								Nenhuma notificação enviada ainda. Use a aba "Enviar Notificação" para começar.
							</CardContent>
						</Card>
					) : (
						notifications.map((notification) => {
							const client = clients.find((c) => c.id === notification.client_id);
							let StatusIcon = Clock;
							let statusColor = "text-gray-600";

							switch (notification.status) {
								case NotificationStatus.Pending:
									StatusIcon = Clock;
									statusColor = "text-yellow-600";
									break;
								case NotificationStatus.Sent:
									StatusIcon = Send;
									statusColor = "text-blue-600";
									break;
								case NotificationStatus.Delivered:
									StatusIcon = CheckCircle2;
									statusColor = "text-green-600";
									break;
								case NotificationStatus.Failed:
									StatusIcon = XCircle;
									statusColor = "text-red-600";
									break;
							}

							const Icon = notification.type === NotificationType.Email ? Mail : MessageSquare;

							return (
								<Card key={notification.id}>
									<CardContent className="p-4">
										<div className="flex items-start justify-between">
											<div className="flex items-start gap-3 flex-1">
												<div
													className={`p-2 rounded-lg ${
														notification.type === NotificationType.Email
															? "bg-blue-100"
															: "bg-green-100"
													}`}
												>
													<Icon
														className={`h-5 w-5 ${
															notification.type === NotificationType.Email
																? "text-blue-600"
																: "text-green-600"
														}`}
													/>
												</div>
												<div className="flex-1">
													<div className="flex items-center gap-2 mb-1">
														<p className="font-medium">{notification.subject}</p>
														<Badge variant="outline">
															<StatusIcon className={`h-3 w-3 mr-1 ${statusColor}`} />
															{STATUS_LABELS[notification.status]}
														</Badge>
													</div>
													<p className="text-sm text-gray-600 mb-2">
														{client?.full_name || "Cliente não identificado"}
													</p>
													<p className="text-sm text-gray-700 line-clamp-2">
														{notification.message}
													</p>
													{notification.sent_at && (
														<p className="text-xs text-gray-500 mt-2">
															Enviado:{" "}
															{new Date(notification.sent_at).toLocaleString("pt-BR")}
														</p>
													)}
													{notification.error_message && (
														<p className="text-xs text-red-600 mt-1">
															Erro: {notification.error_message}
														</p>
													)}
												</div>
											</div>
										</div>
									</CardContent>
								</Card>
							);
						})
					)}
				</TabsContent>

				{/* Configurações */}
				<TabsContent value="settings" className="mt-6">
					<Card>
						<CardHeader>
							<CardTitle>Configurações de Notificações Automáticas</CardTitle>
							<CardDescription>
								Configure quando e como as notificações devem ser enviadas
							</CardDescription>
						</CardHeader>
						<CardContent className="space-y-6">
							<div className="space-y-4">
								<div className="flex items-center justify-between">
									<div>
										<p className="font-medium">Notificações por E-mail</p>
										<p className="text-sm text-gray-500">Enviar notificações via e-mail</p>
									</div>
									<Switch
										checked={settings.emailEnabled}
										onCheckedChange={(checked) =>
											setSettings({ ...settings, emailEnabled: checked })
										}
									/>
								</div>

								<div className="flex items-center justify-between">
									<div>
										<p className="font-medium">Notificações por WhatsApp</p>
										<p className="text-sm text-gray-500">Enviar notificações via WhatsApp</p>
									</div>
									<Switch
										checked={settings.whatsappEnabled}
										onCheckedChange={(checked) =>
											setSettings({ ...settings, whatsappEnabled: checked })
										}
									/>
								</div>
							</div>

							<div className="border-t pt-4 space-y-4">
								<h4 className="font-medium">Notificações Automáticas</h4>

								<div className="flex items-center justify-between">
									<div>
										<p className="font-medium">Alertas de Prazo</p>
										<p className="text-sm text-gray-500">
											Notificar quando prazos estiverem próximos
										</p>
									</div>
									<Switch
										checked={settings.notifyDeadlines}
										onCheckedChange={(checked) =>
											setSettings({ ...settings, notifyDeadlines: checked })
										}
									/>
								</div>

								<div className="flex items-center justify-between">
									<div>
										<p className="font-medium">Novas Demandas</p>
										<p className="text-sm text-gray-500">
											Notificar cliente quando demanda for criada
										</p>
									</div>
									<Switch
										checked={settings.notifyNewDemands}
										onCheckedChange={(checked) =>
											setSettings({ ...settings, notifyNewDemands: checked })
										}
									/>
								</div>

								<div className="flex items-center justify-between">
									<div>
										<p className="font-medium">Vencimento de Parcelas</p>
										<p className="text-sm text-gray-500">
											Notificar sobre vencimento de parcelamentos
										</p>
									</div>
									<Switch
										checked={settings.notifyInstallments}
										onCheckedChange={(checked) =>
											setSettings({ ...settings, notifyInstallments: checked })
										}
									/>
								</div>

								<div className="flex items-center justify-between">
									<div>
										<p className="font-medium">Solicitação de Documentos</p>
										<p className="text-sm text-gray-500">
											Notificar quando documentos forem solicitados
										</p>
									</div>
									<Switch
										checked={settings.notifyDocuments}
										onCheckedChange={(checked) =>
											setSettings({ ...settings, notifyDocuments: checked })
										}
									/>
								</div>
							</div>

							<div className="border-t pt-4">
								<div className="space-y-2">
									<Label htmlFor="warning-days">Antecedência para Alertas de Prazo</Label>
									<Select
										value={settings.deadlineWarningDays.toString()}
										onValueChange={(value) =>
											setSettings({ ...settings, deadlineWarningDays: parseInt(value) })
										}
									>
										<SelectTrigger id="warning-days">
											<SelectValue />
										</SelectTrigger>
										<SelectContent>
											<SelectItem value="3">3 dias antes</SelectItem>
											<SelectItem value="5">5 dias antes</SelectItem>
											<SelectItem value="7">7 dias antes</SelectItem>
											<SelectItem value="10">10 dias antes</SelectItem>
											<SelectItem value="15">15 dias antes</SelectItem>
										</SelectContent>
									</Select>
								</div>
							</div>

							<Alert className="bg-green-50 border-green-200">
								<Zap className="h-4 w-4 text-green-600" />
								<AlertDescription className="text-green-900">
									<strong>Automação Ativa:</strong> As notificações serão enviadas
									automaticamente conforme as configurações acima.
								</AlertDescription>
							</Alert>
						</CardContent>
					</Card>
				</TabsContent>
			</Tabs>
		</div>
	);
}
