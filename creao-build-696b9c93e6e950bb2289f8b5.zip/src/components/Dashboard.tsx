import { SimpleDashboard } from "@/components/SimpleDashboard";

export function Dashboard() {
	return <SimpleDashboard />;
}
