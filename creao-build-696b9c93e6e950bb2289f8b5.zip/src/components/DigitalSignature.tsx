import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
	Shield,
	FileSignature,
	Upload,
	CheckCircle2,
	XCircle,
	Lock,
	Key,
	Calendar,
	AlertCircle,
	Download,
} from "lucide-react";
import { DocumentORM, type DocumentModel } from "@/components/data/orm/orm_document";

/**
 * Status do certificado A1
 */
enum CertificateStatus {
	NotInstalled = "Não Instalado",
	Valid = "Válido",
	Expired = "Expirado",
	Invalid = "Inválido",
}

/**
 * Interface do certificado A1
 */
interface CertificateInfo {
	status: CertificateStatus;
	owner: string;
	cpfCnpj: string;
	issuer: string;
	validFrom: Date;
	validUntil: Date;
	serialNumber: string;
}

/**
 * Verifica se o certificado está próximo do vencimento
 */
function isNearExpiration(validUntil: Date): boolean {
	const today = new Date();
	const daysUntilExpiration = Math.ceil(
		(validUntil.getTime() - today.getTime()) / (1000 * 60 * 60 * 24)
	);
	return daysUntilExpiration <= 30 && daysUntilExpiration > 0;
}

/**
 * Verifica se o certificado está expirado
 */
function isExpired(validUntil: Date): boolean {
	return validUntil < new Date();
}

/**
 * Formata data para exibição
 */
function formatDate(date: Date): string {
	return new Intl.DateTimeFormat("pt-BR").format(date);
}

/**
 * Simula a leitura de certificado A1 de arquivo .pfx
 */
function loadCertificateFromFile(file: File, password: string): Promise<CertificateInfo> {
	return new Promise((resolve, reject) => {
		setTimeout(() => {
			// Simulação - em produção, usar biblioteca como node-forge ou crypto
			if (password !== "123456") {
				reject(new Error("Senha incorreta"));
				return;
			}

			const validUntil = new Date();
			validUntil.setMonth(validUntil.getMonth() + 6);

			resolve({
				status: CertificateStatus.Valid,
				owner: "CL ASSESSORIA E CONSULTORIA DIGITAL",
				cpfCnpj: "12.345.678/0001-90",
				issuer: "AC Certisign",
				validFrom: new Date(2024, 0, 1),
				validUntil: validUntil,
				serialNumber: "1234567890ABCDEF",
			});
		}, 1500);
	});
}

/**
 * Simula a assinatura digital de documento
 */
function signDocument(
	document: DocumentModel,
	certificate: CertificateInfo
): Promise<{ success: boolean; signedUrl: string }> {
	return new Promise((resolve) => {
		setTimeout(() => {
			console.log("Assinando documento:", document.file_info.file_name);
			console.log("Certificado:", certificate.owner);

			resolve({
				success: true,
				signedUrl: `${document.file_info.file_url}_signed.pdf`,
			});
		}, 2000);
	});
}

export function DigitalSignature() {
	const [certificate, setCertificate] = React.useState<CertificateInfo | null>(null);
	const [documents, setDocuments] = React.useState<DocumentModel[]>([]);
	const [loading, setLoading] = React.useState(true);
	const [uploadingCert, setUploadingCert] = React.useState(false);
	const [signingDoc, setSigningDoc] = React.useState<string | null>(null);

	// Formulário de upload de certificado
	const [certFile, setCertFile] = React.useState<File | null>(null);
	const [certPassword, setCertPassword] = React.useState("");
	const [certError, setCertError] = React.useState("");

	const documentORM = React.useMemo(() => DocumentORM.getInstance(), []);

	React.useEffect(() => {
		loadDocuments();
	}, []);

	const loadDocuments = async () => {
		try {
			setLoading(true);
			const allDocuments = await documentORM.getAllDocument();
			setDocuments(allDocuments);
		} catch (error) {
			console.error("Erro ao carregar documentos:", error);
		} finally {
			setLoading(false);
		}
	};

	const handleCertFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
		const file = e.target.files?.[0];
		if (file) {
			setCertFile(file);
			setCertError("");
		}
	};

	const handleInstallCertificate = async () => {
		if (!certFile || !certPassword) {
			setCertError("Selecione o arquivo .pfx e informe a senha");
			return;
		}

		setUploadingCert(true);
		setCertError("");

		try {
			const certInfo = await loadCertificateFromFile(certFile, certPassword);
			setCertificate(certInfo);
			setCertPassword("");
			alert("Certificado instalado com sucesso!");
		} catch (error) {
			setCertError((error as Error).message || "Erro ao carregar certificado");
		} finally {
			setUploadingCert(false);
		}
	};

	const handleSignDocument = async (document: DocumentModel) => {
		if (!certificate) {
			alert("Instale um certificado antes de assinar documentos");
			return;
		}

		if (certificate.status !== CertificateStatus.Valid) {
			alert("Certificado inválido ou expirado");
			return;
		}

		setSigningDoc(document.id);

		try {
			const result = await signDocument(document, certificate);
			if (result.success) {
				alert(
					`Documento "${document.file_info.file_name}" assinado com sucesso!\n\n` +
					`URL do documento assinado: ${result.signedUrl}\n\n` +
					`Em produção, o documento seria assinado digitalmente com o certificado A1.`
				);
			}
		} catch (error) {
			alert("Erro ao assinar documento: " + (error as Error).message);
		} finally {
			setSigningDoc(null);
		}
	};

	const daysUntilExpiration = certificate
		? Math.ceil(
			(certificate.validUntil.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)
		  )
		: 0;

	return (
		<div className="space-y-6">
			<div>
				<h2 className="text-3xl font-bold text-gray-900">Assinatura Digital A1</h2>
				<p className="text-sm text-gray-600 mt-1">
					Integração com certificado digital para assinatura de documentos
				</p>
			</div>

			{/* Status do Certificado */}
			<Card>
				<CardHeader>
					<div className="flex items-center gap-3">
						<div className={`p-2 rounded-lg ${certificate ? "bg-green-600" : "bg-gray-600"} text-white`}>
							<Shield className="h-6 w-6" />
						</div>
						<div>
							<CardTitle>Status do Certificado Digital</CardTitle>
							<CardDescription>
								{certificate
									? "Certificado instalado e pronto para uso"
									: "Nenhum certificado instalado"}
							</CardDescription>
						</div>
					</div>
				</CardHeader>
				<CardContent>
					{certificate ? (
						<div className="space-y-4">
							<div className="grid grid-cols-1 md:grid-cols-2 gap-4">
								<div>
									<p className="text-sm text-gray-600 mb-1">Status</p>
									<div className="flex items-center gap-2">
										{certificate.status === CertificateStatus.Valid ? (
											<CheckCircle2 className="h-4 w-4 text-green-600" />
										) : (
											<XCircle className="h-4 w-4 text-red-600" />
										)}
										<Badge
											variant={
												certificate.status === CertificateStatus.Valid
													? "default"
													: "destructive"
											}
										>
											{certificate.status}
										</Badge>
									</div>
								</div>

								<div>
									<p className="text-sm text-gray-600 mb-1">Titular</p>
									<p className="text-sm font-medium">{certificate.owner}</p>
								</div>

								<div>
									<p className="text-sm text-gray-600 mb-1">CPF/CNPJ</p>
									<p className="text-sm font-medium">{certificate.cpfCnpj}</p>
								</div>

								<div>
									<p className="text-sm text-gray-600 mb-1">Emissor</p>
									<p className="text-sm font-medium">{certificate.issuer}</p>
								</div>

								<div>
									<p className="text-sm text-gray-600 mb-1">Válido de</p>
									<p className="text-sm font-medium">
										{formatDate(certificate.validFrom)}
									</p>
								</div>

								<div>
									<p className="text-sm text-gray-600 mb-1">Válido até</p>
									<p
										className={`text-sm font-medium ${
											isExpired(certificate.validUntil)
												? "text-red-600"
												: isNearExpiration(certificate.validUntil)
												? "text-yellow-600"
												: ""
										}`}
									>
										{formatDate(certificate.validUntil)}
										{isNearExpiration(certificate.validUntil) &&
											!isExpired(certificate.validUntil) && (
												<span className="text-xs ml-1">
													({daysUntilExpiration} dias)
												</span>
											)}
									</p>
								</div>

								<div>
									<p className="text-sm text-gray-600 mb-1">Número de Série</p>
									<p className="text-sm font-mono">{certificate.serialNumber}</p>
								</div>
							</div>

							{isNearExpiration(certificate.validUntil) &&
								!isExpired(certificate.validUntil) && (
									<Alert>
										<AlertCircle className="h-4 w-4" />
										<AlertTitle>Atenção: Certificado próximo do vencimento</AlertTitle>
										<AlertDescription>
											Seu certificado vence em {daysUntilExpiration} dias. Providencie a renovação
											para evitar interrupção dos serviços.
										</AlertDescription>
									</Alert>
								)}

							{isExpired(certificate.validUntil) && (
								<Alert variant="destructive">
									<XCircle className="h-4 w-4" />
									<AlertTitle>Certificado Expirado</AlertTitle>
									<AlertDescription>
										Seu certificado digital está expirado. Instale um novo certificado para
										continuar assinando documentos.
									</AlertDescription>
								</Alert>
							)}

							<Button variant="outline" onClick={() => setCertificate(null)}>
								<XCircle className="h-4 w-4 mr-2" />
								Remover Certificado
							</Button>
						</div>
					) : (
						<div className="space-y-4">
							<div className="space-y-2">
								<Label htmlFor="cert-file">Arquivo do Certificado (.pfx ou .p12)</Label>
								<Input
									id="cert-file"
									type="file"
									accept=".pfx,.p12"
									onChange={handleCertFileChange}
								/>
							</div>

							<div className="space-y-2">
								<Label htmlFor="cert-password">Senha do Certificado</Label>
								<Input
									id="cert-password"
									type="password"
									value={certPassword}
									onChange={(e) => setCertPassword(e.target.value)}
									placeholder="Digite a senha do certificado"
								/>
								<p className="text-xs text-gray-500">
									Para teste, use a senha: 123456
								</p>
							</div>

							{certError && (
								<Alert variant="destructive">
									<XCircle className="h-4 w-4" />
									<AlertDescription>{certError}</AlertDescription>
								</Alert>
							)}

							<Button
								onClick={handleInstallCertificate}
								disabled={!certFile || !certPassword || uploadingCert}
								className="w-full"
							>
								<Lock className="h-4 w-4 mr-2" />
								{uploadingCert ? "Instalando..." : "Instalar Certificado"}
							</Button>

							<Alert>
								<Key className="h-4 w-4" />
								<AlertDescription className="text-sm">
									<strong>Segurança:</strong> Seu certificado digital é criptografado e
									processado localmente. Em ambiente de produção, use sempre conexão HTTPS e
									módulos de segurança homologados pela ICP-Brasil.
								</AlertDescription>
							</Alert>
						</div>
					)}
				</CardContent>
			</Card>

			{/* Lista de Documentos para Assinar */}
			<div className="space-y-4">
				<div className="flex items-center justify-between">
					<h3 className="text-xl font-bold text-gray-900">Documentos Disponíveis</h3>
					<Badge variant="outline">
						{documents.length} documento{documents.length !== 1 ? "s" : ""}
					</Badge>
				</div>

				{loading ? (
					<Card>
						<CardContent className="p-8 text-center text-gray-500">
							Carregando documentos...
						</CardContent>
					</Card>
				) : documents.length === 0 ? (
					<Card>
						<CardContent className="p-8 text-center text-gray-500">
							Nenhum documento disponível para assinatura.
						</CardContent>
					</Card>
				) : (
					<div className="grid gap-3">
						{documents.map((document) => (
							<Card key={document.id}>
								<CardContent className="p-4">
									<div className="flex items-center justify-between">
										<div className="flex items-center gap-3 flex-1">
											<FileSignature className="h-8 w-8 text-blue-600" />
											<div>
												<p className="font-medium">{document.file_info.file_name}</p>
												<p className="text-xs text-gray-500">
													{document.document_type} •{" "}
													{(document.file_info.file_size / 1024).toFixed(1)} KB
												</p>
											</div>
										</div>
										<div className="flex gap-2">
											<Button
												size="sm"
												variant="outline"
												onClick={() => window.open(document.file_info.file_url, "_blank")}
											>
												<Download className="h-4 w-4 mr-1" />
												Baixar
											</Button>
											<Button
												size="sm"
												onClick={() => handleSignDocument(document)}
												disabled={!certificate || signingDoc === document.id}
											>
												<FileSignature className="h-4 w-4 mr-1" />
												{signingDoc === document.id ? "Assinando..." : "Assinar"}
											</Button>
										</div>
									</div>
								</CardContent>
							</Card>
						))}
					</div>
				)}
			</div>

			{/* Informações Adicionais */}
			<Card className="bg-blue-50 border-blue-200">
				<CardHeader>
					<CardTitle className="text-blue-900">Sobre Certificados A1</CardTitle>
				</CardHeader>
				<CardContent className="text-sm text-blue-900 space-y-2">
					<p>
						<strong>O que é:</strong> Certificado digital modelo A1 é armazenado diretamente
						no computador, facilitando o uso em sistemas web.
					</p>
					<p>
						<strong>Validade:</strong> Certificados A1 têm validade de 1 ano.
					</p>
					<p>
						<strong>Uso:</strong> Ideal para assinatura de documentos, notas fiscais eletrônicas,
						e processos administrativos.
					</p>
					<p>
						<strong>Segurança:</strong> Este sistema usa criptografia de ponta-a-ponta e não
						armazena senhas.
					</p>
				</CardContent>
			</Card>
		</div>
	);
}
