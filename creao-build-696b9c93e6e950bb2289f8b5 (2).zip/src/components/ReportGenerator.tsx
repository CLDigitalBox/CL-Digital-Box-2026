import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import {
	FileText,
	Download,
	Calendar,
	TrendingUp,
	Users,
	Briefcase,
	Building2,
	BarChart3,
	FileSpreadsheet,
	Mail,
	Send,
} from "lucide-react";
import { ClientORM, type ClientModel } from "@/components/data/orm/orm_client";
import { DemandORM, type DemandModel, DemandStatus } from "@/components/data/orm/orm_demand";
import { DocumentORM, type DocumentModel } from "@/components/data/orm/orm_document";
import { sendEmail, createReportEmailTemplate } from "@/lib/email";

/**
 * Tipos de relatórios disponíveis
 */
enum ReportType {
	Institutional = "Relatório Institucional",
	ClientActivity = "Relatório de Atividades por Cliente",
	DemandStatus = "Relatório de Status de Demandas",
	MonthlyStatistics = "Estatísticas Mensais",
	DocumentInventory = "Inventário de Documentos",
}

/**
 * Configuração dos relatórios
 */
const REPORT_CONFIG = {
	[ReportType.Institutional]: {
		icon: Building2,
		color: "bg-blue-600",
		description: "Relatório geral da empresa com todos os indicadores",
		includeCharts: true,
	},
	[ReportType.ClientActivity]: {
		icon: Users,
		color: "bg-green-600",
		description: "Atividades e demandas por cliente específico",
		includeCharts: false,
	},
	[ReportType.DemandStatus]: {
		icon: Briefcase,
		color: "bg-purple-600",
		description: "Status atual de todas as demandas em andamento",
		includeCharts: true,
	},
	[ReportType.MonthlyStatistics]: {
		icon: TrendingUp,
		color: "bg-orange-600",
		description: "Estatísticas e indicadores do mês corrente",
		includeCharts: true,
	},
	[ReportType.DocumentInventory]: {
		icon: FileText,
		color: "bg-gray-600",
		description: "Listagem completa de documentos armazenados",
		includeCharts: false,
	},
};

/**
 * Gera PDF do relatório (simulado)
 * Em produção, usar bibliotecas como jsPDF ou pdfmake
 */
function generatePDFReport(
	reportType: ReportType,
	data: {
		clients: ClientModel[];
		demands: DemandModel[];
		documents: DocumentModel[];
	},
	selectedClient?: string,
	includeGraphics?: boolean
): void {
	const config = REPORT_CONFIG[reportType];
	const timestamp = new Date().toLocaleString("pt-BR");

	let reportContent = "";

	switch (reportType) {
		case ReportType.Institutional:
			reportContent = generateInstitutionalReport(data);
			break;
		case ReportType.ClientActivity:
			if (selectedClient) {
				const client = data.clients.find((c) => c.id === selectedClient);
				reportContent = generateClientActivityReport(client, data);
			}
			break;
		case ReportType.DemandStatus:
			reportContent = generateDemandStatusReport(data);
			break;
		case ReportType.MonthlyStatistics:
			reportContent = generateMonthlyStatisticsReport(data);
			break;
		case ReportType.DocumentInventory:
			reportContent = generateDocumentInventoryReport(data);
			break;
	}

	// Simulação de geração de PDF
	console.log("=== RELATÓRIO PDF GERADO ===");
	console.log("Tipo:", reportType);
	console.log("Data/Hora:", timestamp);
	console.log("Incluir Gráficos:", includeGraphics);
	console.log("\n" + reportContent);

	alert(
		`Relatório "${reportType}" gerado com sucesso!\n\n` +
		`Data/Hora: ${timestamp}\n` +
		`Gráficos: ${includeGraphics ? "Sim" : "Não"}\n\n` +
		`Em produção, um arquivo PDF seria baixado automaticamente.\n` +
		`Verifique o console para ver o conteúdo completo.`
	);
}

function generateInstitutionalReport(data: {
	clients: ClientModel[];
	demands: DemandModel[];
	documents: DocumentModel[];
}): string {
	return `
═══════════════════════════════════════════════════════
  CL ASSESSORIA E CONSULTORIA DIGITAL
  RELATÓRIO INSTITUCIONAL
  Santa Bárbara, MG - Brasil
═══════════════════════════════════════════════════════

1. RESUMO EXECUTIVO
   - Total de Clientes: ${data.clients.length}
   - Total de Demandas: ${data.demands.length}
   - Total de Documentos: ${data.documents.length}

2. ANÁLISE DE DEMANDAS
   - Novas: ${data.demands.filter((d) => d.status === DemandStatus.New).length}
   - Em Andamento: ${data.demands.filter((d) => d.status === DemandStatus.InProgress).length}
   - Concluídas: ${data.demands.filter((d) => d.status === DemandStatus.Concluded).length}
   - Aguardando: ${data.demands.filter((d) => d.status === DemandStatus.Waiting).length}
   - Suspensas: ${data.demands.filter((d) => d.status === DemandStatus.Suspended).length}

3. INDICADORES DE PERFORMANCE
   - Taxa de Conclusão: ${((data.demands.filter((d) => d.status === DemandStatus.Concluded).length / data.demands.length) * 100).toFixed(1)}%
   - Média de Documentos por Cliente: ${(data.documents.length / data.clients.length).toFixed(1)}
   - Média de Demandas por Cliente: ${(data.demands.length / data.clients.length).toFixed(1)}
`;
}

function generateClientActivityReport(
	client: ClientModel | undefined,
	data: { demands: DemandModel[]; documents: DocumentModel[] }
): string {
	if (!client) return "Cliente não encontrado.";

	const clientDemands = data.demands.filter((d) => d.client_id === client.id);
	const clientDocs = data.documents.filter((d) => d.client_id === client.id);

	return `
═══════════════════════════════════════════════════════
  RELATÓRIO DE ATIVIDADES DO CLIENTE
═══════════════════════════════════════════════════════

CLIENTE: ${client.full_name}
CPF/CNPJ: ${client.cpf_cnpj || "Não informado"}
E-mail: ${client.contact_info?.email || "Não informado"}
Telefone: ${client.contact_info?.phone_primary || "Não informado"}

RESUMO DE ATIVIDADES:
- Total de Demandas: ${clientDemands.length}
- Total de Documentos: ${clientDocs.length}

DEMANDAS:
${clientDemands.map((d, i) => `${i + 1}. ${d.demand_number} - Status: ${d.status}`).join("\n")}

DOCUMENTOS:
${clientDocs.map((d, i) => `${i + 1}. ${d.document_type} - ${d.file_info.file_name}`).join("\n")}
`;
}

function generateDemandStatusReport(data: { demands: DemandModel[] }): string {
	const byStatus = data.demands.reduce((acc, d) => {
		const status = d.status.toString();
		if (!acc[status]) acc[status] = [];
		acc[status].push(d);
		return acc;
	}, {} as Record<string, DemandModel[]>);

	return `
═══════════════════════════════════════════════════════
  RELATÓRIO DE STATUS DE DEMANDAS
═══════════════════════════════════════════════════════

${Object.entries(byStatus)
	.map(
		([status, demands]) =>
			`\n${status.toUpperCase()}:\n${demands.map((d, i) => `  ${i + 1}. ${d.demand_number} - ${d.description || "Sem descrição"}`).join("\n")}`
	)
	.join("\n")}
`;
}

function generateMonthlyStatisticsReport(data: {
	clients: ClientModel[];
	demands: DemandModel[];
	documents: DocumentModel[];
}): string {
	const monthName = new Intl.DateTimeFormat("pt-BR", { month: "long", year: "numeric" }).format(
		new Date()
	);

	return `
═══════════════════════════════════════════════════════
  ESTATÍSTICAS MENSAIS - ${monthName.toUpperCase()}
═══════════════════════════════════════════════════════

CLIENTES:
- Total de Clientes Ativos: ${data.clients.length}
- Novos Clientes no Mês: 0 (não rastreado)

DEMANDAS:
- Novas Demandas: ${data.demands.filter((d) => d.status === DemandStatus.New).length}
- Demandas Concluídas: ${data.demands.filter((d) => d.status === DemandStatus.Concluded).length}
- Demandas em Andamento: ${data.demands.filter((d) => d.status === DemandStatus.InProgress).length}
- Taxa de Sucesso: ${((data.demands.filter((d) => d.status === DemandStatus.Concluded).length / data.demands.length) * 100).toFixed(1)}%

DOCUMENTOS:
- Total de Documentos: ${data.documents.length}
- Média por Cliente: ${(data.documents.length / data.clients.length).toFixed(1)}
`;
}

function generateDocumentInventoryReport(data: { documents: DocumentModel[] }): string {
	return `
═══════════════════════════════════════════════════════
  INVENTÁRIO DE DOCUMENTOS
═══════════════════════════════════════════════════════

Total de Documentos: ${data.documents.length}

LISTA COMPLETA:
${data.documents
	.map(
		(d, i) =>
			`${i + 1}. ${d.document_type} - ${d.file_info.file_name} - Status: ${d.status}`
	)
	.join("\n")}
`;
}

/**
 * Exporta dados para CSV
 */
function exportToCSV(
	data: {
		clients: ClientModel[];
		demands: DemandModel[];
		documents: DocumentModel[];
	},
	type: "clients" | "demands" | "documents" | "all"
): void {
	let csvContent = "";
	let filename = "";

	if (type === "clients" || type === "all") {
		csvContent += "CLIENTES\n";
		csvContent += "ID,Nome,CPF/CNPJ,Email,Telefone,Endereço\n";
		data.clients.forEach((client) => {
			csvContent += `"${client.id}","${client.full_name}","${client.cpf_cnpj || ""}","${client.contact_info?.email || ""}","${client.contact_info?.phone_primary || ""}","${client.address_info?.street || ""}"\n`;
		});
		csvContent += "\n";
	}

	if (type === "demands" || type === "all") {
		csvContent += "DEMANDAS\n";
		csvContent += "ID,Número,Cliente ID,Tipo,Status,Prioridade,Data Cadastro,Prazo\n";
		data.demands.forEach((demand) => {
			csvContent += `"${demand.id}","${demand.demand_number}","${demand.client_id}","${demand.demand_type}","${demand.status}","${demand.priority}","${demand.dates?.registration_date || ""}","${demand.dates?.deadline || ""}"\n`;
		});
		csvContent += "\n";
	}

	if (type === "documents" || type === "all") {
		csvContent += "DOCUMENTOS\n";
		csvContent += "ID,Cliente ID,Tipo,Nome do Arquivo,Status,Tamanho,Data Criação\n";
		data.documents.forEach((doc) => {
			csvContent += `"${doc.id}","${doc.client_id}","${doc.document_type}","${doc.file_info.file_name}","${doc.status}","${doc.file_info.file_size || 0}","${doc.create_time || ""}"\n`;
		});
	}

	filename = `cl_digital_${type}_${new Date().toISOString().split("T")[0]}.csv`;

	const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
	const link = document.createElement("a");
	const url = URL.createObjectURL(blob);
	link.setAttribute("href", url);
	link.setAttribute("download", filename);
	link.style.visibility = "hidden";
	document.body.appendChild(link);
	link.click();
	document.body.removeChild(link);

	console.log(`Arquivo CSV exportado: ${filename}`);
}

/**
 * Exporta dados para formato Excel-compatível (HTML com meta tags)
 */
function exportToExcel(
	data: {
		clients: ClientModel[];
		demands: DemandModel[];
		documents: DocumentModel[];
	},
	type: "clients" | "demands" | "documents" | "all"
): void {
	let htmlContent = `
<html xmlns:o="urn:schemas-microsoft-com:office:office"
      xmlns:x="urn:schemas-microsoft-com:office:excel"
      xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="content-type" content="application/vnd.ms-excel; charset=UTF-8">
	<style>
		table { border-collapse: collapse; width: 100%; }
		th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
		th { background-color: #2563eb; color: white; font-weight: bold; }
		tr:nth-child(even) { background-color: #f2f2f2; }
		h2 { color: #2563eb; margin-top: 20px; }
	</style>
</head>
<body>
	<h1>CL Assessoria e Consultoria Digital - Relatório de Dados</h1>
	<p>Gerado em: ${new Date().toLocaleString("pt-BR")}</p>
`;

	if (type === "clients" || type === "all") {
		htmlContent += `
	<h2>CLIENTES</h2>
	<table>
		<thead>
			<tr>
				<th>ID</th>
				<th>Nome</th>
				<th>CPF/CNPJ</th>
				<th>Email</th>
				<th>Telefone</th>
				<th>Endereço</th>
			</tr>
		</thead>
		<tbody>
			${data.clients
				.map(
					(client) => `
			<tr>
				<td>${client.id}</td>
				<td>${client.full_name}</td>
				<td>${client.cpf_cnpj || ""}</td>
				<td>${client.contact_info?.email || ""}</td>
				<td>${client.contact_info?.phone_primary || ""}</td>
				<td>${client.address_info?.street || ""}</td>
			</tr>`
				)
				.join("")}
		</tbody>
	</table>
`;
	}

	if (type === "demands" || type === "all") {
		htmlContent += `
	<h2>DEMANDAS</h2>
	<table>
		<thead>
			<tr>
				<th>ID</th>
				<th>Número</th>
				<th>Cliente ID</th>
				<th>Tipo</th>
				<th>Status</th>
				<th>Prioridade</th>
				<th>Data Cadastro</th>
				<th>Prazo</th>
			</tr>
		</thead>
		<tbody>
			${data.demands
				.map(
					(demand) => `
			<tr>
				<td>${demand.id}</td>
				<td>${demand.demand_number}</td>
				<td>${demand.client_id}</td>
				<td>${demand.demand_type}</td>
				<td>${demand.status}</td>
				<td>${demand.priority}</td>
				<td>${demand.dates?.registration_date || ""}</td>
				<td>${demand.dates?.deadline || ""}</td>
			</tr>`
				)
				.join("")}
		</tbody>
	</table>
`;
	}

	if (type === "documents" || type === "all") {
		htmlContent += `
	<h2>DOCUMENTOS</h2>
	<table>
		<thead>
			<tr>
				<th>ID</th>
				<th>Cliente ID</th>
				<th>Tipo</th>
				<th>Nome do Arquivo</th>
				<th>Status</th>
				<th>Tamanho (bytes)</th>
				<th>Data Criação</th>
			</tr>
		</thead>
		<tbody>
			${data.documents
				.map(
					(doc) => `
			<tr>
				<td>${doc.id}</td>
				<td>${doc.client_id}</td>
				<td>${doc.document_type}</td>
				<td>${doc.file_info.file_name}</td>
				<td>${doc.status}</td>
				<td>${doc.file_info.file_size || 0}</td>
				<td>${doc.create_time || ""}</td>
			</tr>`
				)
				.join("")}
		</tbody>
	</table>
`;
	}

	htmlContent += `
</body>
</html>
`;

	const filename = `cl_digital_${type}_${new Date().toISOString().split("T")[0]}.xls`;
	const blob = new Blob([htmlContent], { type: "application/vnd.ms-excel" });
	const link = document.createElement("a");
	const url = URL.createObjectURL(blob);
	link.setAttribute("href", url);
	link.setAttribute("download", filename);
	link.style.visibility = "hidden";
	document.body.appendChild(link);
	link.click();
	document.body.removeChild(link);

	console.log(`Arquivo Excel exportado: ${filename}`);
}

export function ReportGenerator() {
	const [clients, setClients] = React.useState<ClientModel[]>([]);
	const [demands, setDemands] = React.useState<DemandModel[]>([]);
	const [documents, setDocuments] = React.useState<DocumentModel[]>([]);
	const [loading, setLoading] = React.useState(true);
	const [sendingEmail, setSendingEmail] = React.useState(false);

	const [selectedReport, setSelectedReport] = React.useState<ReportType>(
		ReportType.Institutional
	);
	const [selectedClient, setSelectedClient] = React.useState<string>("");
	const [includeGraphics, setIncludeGraphics] = React.useState(true);
	const [emailRecipient, setEmailRecipient] = React.useState("");

	const clientORM = React.useMemo(() => ClientORM.getInstance(), []);
	const demandORM = React.useMemo(() => DemandORM.getInstance(), []);
	const documentORM = React.useMemo(() => DocumentORM.getInstance(), []);

	React.useEffect(() => {
		loadData();
	}, []);

	const loadData = async () => {
		try {
			setLoading(true);
			const [allClients, allDemands, allDocuments] = await Promise.all([
				clientORM.getAllClient(),
				demandORM.getAllDemand(),
				documentORM.getAllDocument(),
			]);

			setClients(allClients);
			setDemands(allDemands);
			setDocuments(allDocuments);
		} catch (error) {
			console.error("Erro ao carregar dados:", error);
		} finally {
			setLoading(false);
		}
	};

	const handleGenerate = () => {
		generatePDFReport(
			selectedReport,
			{ clients, demands, documents },
			selectedClient,
			includeGraphics
		);
	};

	const handleSendByEmail = async () => {
		if (!emailRecipient) {
			alert("Informe o email do destinatário");
			return;
		}

		// Validação básica de email
		const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
		if (!emailRegex.test(emailRecipient)) {
			alert("Email inválido");
			return;
		}

		setSendingEmail(true);

		try {
			// Em produção, aqui você geraria o PDF e hospedaria em algum lugar (S3, etc)
			const pdfUrl = "https://exemplo.com/relatorio.pdf";

			const clientName = selectedClient
				? clients.find((c) => c.id === selectedClient)?.full_name || "Cliente"
				: "CL Assessoria";

			const emailHtml = createReportEmailTemplate(
				clientName,
				selectedReport,
				pdfUrl
			);

			const result = await sendEmail({
				to: emailRecipient,
				subject: `Relatório PDF: ${selectedReport}`,
				html: emailHtml,
				text: `Olá ${clientName},\n\nSeu relatório "${selectedReport}" foi gerado com sucesso.\n\nBaixe em: ${pdfUrl}\n\nAtenciosamente,\nCL Assessoria`,
			});

			if (result.success) {
				alert(
					`✅ Email enviado com sucesso para ${emailRecipient}!\n\n` +
					`ID da Mensagem: ${result.messageId}\n\n` +
					`O destinatário receberá o link para download do relatório.`
				);
				setEmailRecipient("");
			} else {
				throw new Error(result.error || "Erro desconhecido");
			}
		} catch (error) {
			alert(`❌ Erro ao enviar email: ${(error as Error).message}`);
		} finally {
			setSendingEmail(false);
		}
	};

	const config = REPORT_CONFIG[selectedReport];
	const Icon = config.icon;
	const needsClientSelection = selectedReport === ReportType.ClientActivity;

	return (
		<div className="space-y-6">
			<div>
				<h2 className="text-3xl font-bold text-gray-900">Geração de Relatórios PDF</h2>
				<p className="text-sm text-gray-600 mt-1">
					Relatórios institucionais automáticos em formato PDF
				</p>
			</div>

			{/* Estatísticas Rápidas */}
			<div className="grid grid-cols-1 md:grid-cols-3 gap-4">
				<Card>
					<CardHeader className="pb-2">
						<CardTitle className="text-sm font-medium text-gray-600">
							Clientes Cadastrados
						</CardTitle>
					</CardHeader>
					<CardContent>
						<div className="text-2xl font-bold">{clients.length}</div>
					</CardContent>
				</Card>

				<Card>
					<CardHeader className="pb-2">
						<CardTitle className="text-sm font-medium text-gray-600">
							Demandas Ativas
						</CardTitle>
					</CardHeader>
					<CardContent>
						<div className="text-2xl font-bold">{demands.length}</div>
					</CardContent>
				</Card>

				<Card>
					<CardHeader className="pb-2">
						<CardTitle className="text-sm font-medium text-gray-600">
							Documentos Armazenados
						</CardTitle>
					</CardHeader>
					<CardContent>
						<div className="text-2xl font-bold">{documents.length}</div>
					</CardContent>
				</Card>
			</div>

			{/* Exportação de Dados */}
			<Card className="border-green-200 bg-green-50">
				<CardHeader>
					<div className="flex items-center gap-3">
						<div className="p-2 rounded-lg bg-green-600 text-white">
							<FileSpreadsheet className="h-6 w-6" />
						</div>
						<div>
							<CardTitle className="text-green-900">Exportar Dados</CardTitle>
							<CardDescription className="text-green-700">
								Baixe seus dados em formato CSV ou Excel para análise externa
							</CardDescription>
						</div>
					</div>
				</CardHeader>
				<CardContent>
					<div className="grid grid-cols-2 md:grid-cols-4 gap-3">
						<Button
							onClick={() => exportToCSV({ clients, demands, documents }, "clients")}
							variant="outline"
							className="flex flex-col h-auto py-4 border-green-300 hover:bg-green-100"
							disabled={loading || clients.length === 0}
						>
							<FileSpreadsheet className="h-6 w-6 mb-2 text-green-600" />
							<span className="font-medium">CSV</span>
							<span className="text-xs text-gray-600">Clientes</span>
						</Button>
						<Button
							onClick={() => exportToCSV({ clients, demands, documents }, "demands")}
							variant="outline"
							className="flex flex-col h-auto py-4 border-green-300 hover:bg-green-100"
							disabled={loading || demands.length === 0}
						>
							<FileSpreadsheet className="h-6 w-6 mb-2 text-green-600" />
							<span className="font-medium">CSV</span>
							<span className="text-xs text-gray-600">Demandas</span>
						</Button>
						<Button
							onClick={() => exportToCSV({ clients, demands, documents }, "documents")}
							variant="outline"
							className="flex flex-col h-auto py-4 border-green-300 hover:bg-green-100"
							disabled={loading || documents.length === 0}
						>
							<FileSpreadsheet className="h-6 w-6 mb-2 text-green-600" />
							<span className="font-medium">CSV</span>
							<span className="text-xs text-gray-600">Documentos</span>
						</Button>
						<Button
							onClick={() => exportToCSV({ clients, demands, documents }, "all")}
							variant="outline"
							className="flex flex-col h-auto py-4 border-green-300 hover:bg-green-100"
							disabled={loading}
						>
							<FileSpreadsheet className="h-6 w-6 mb-2 text-green-600" />
							<span className="font-medium">CSV</span>
							<span className="text-xs text-gray-600">Tudo</span>
						</Button>
					</div>
					<div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-3">
						<Button
							onClick={() => exportToExcel({ clients, demands, documents }, "clients")}
							variant="default"
							className="flex flex-col h-auto py-4 bg-green-600 hover:bg-green-700"
							disabled={loading || clients.length === 0}
						>
							<FileSpreadsheet className="h-6 w-6 mb-2" />
							<span className="font-medium">Excel</span>
							<span className="text-xs opacity-90">Clientes</span>
						</Button>
						<Button
							onClick={() => exportToExcel({ clients, demands, documents }, "demands")}
							variant="default"
							className="flex flex-col h-auto py-4 bg-green-600 hover:bg-green-700"
							disabled={loading || demands.length === 0}
						>
							<FileSpreadsheet className="h-6 w-6 mb-2" />
							<span className="font-medium">Excel</span>
							<span className="text-xs opacity-90">Demandas</span>
						</Button>
						<Button
							onClick={() => exportToExcel({ clients, demands, documents }, "documents")}
							variant="default"
							className="flex flex-col h-auto py-4 bg-green-600 hover:bg-green-700"
							disabled={loading || documents.length === 0}
						>
							<FileSpreadsheet className="h-6 w-6 mb-2" />
							<span className="font-medium">Excel</span>
							<span className="text-xs opacity-90">Documentos</span>
						</Button>
						<Button
							onClick={() => exportToExcel({ clients, demands, documents }, "all")}
							variant="default"
							className="flex flex-col h-auto py-4 bg-green-600 hover:bg-green-700"
							disabled={loading}
						>
							<FileSpreadsheet className="h-6 w-6 mb-2" />
							<span className="font-medium">Excel</span>
							<span className="text-xs opacity-90">Tudo</span>
						</Button>
					</div>
				</CardContent>
			</Card>

			{/* Configuração do Relatório */}
			<Card>
				<CardHeader>
					<div className="flex items-center gap-3">
						<div className={`p-2 rounded-lg ${config.color} text-white`}>
							<Icon className="h-6 w-6" />
						</div>
						<div>
							<CardTitle>Configurar Relatório</CardTitle>
							<CardDescription>{config.description}</CardDescription>
						</div>
					</div>
				</CardHeader>
				<CardContent className="space-y-6">
					<div className="space-y-2">
						<Label htmlFor="report-type">Tipo de Relatório *</Label>
						<Select
							value={selectedReport}
							onValueChange={(value) => setSelectedReport(value as ReportType)}
						>
							<SelectTrigger id="report-type">
								<SelectValue />
							</SelectTrigger>
							<SelectContent>
								{Object.entries(ReportType).map(([key, value]) => (
									<SelectItem key={key} value={value}>
										{value}
									</SelectItem>
								))}
							</SelectContent>
						</Select>
					</div>

					{needsClientSelection && (
						<div className="space-y-2">
							<Label htmlFor="client">Cliente *</Label>
							<Select value={selectedClient} onValueChange={setSelectedClient}>
								<SelectTrigger id="client">
									<SelectValue placeholder="Selecione o cliente" />
								</SelectTrigger>
								<SelectContent>
									{clients.map((client) => (
										<SelectItem key={client.id} value={client.id}>
											{client.full_name}
										</SelectItem>
									))}
								</SelectContent>
							</Select>
						</div>
					)}

					{config.includeCharts && (
						<div className="flex items-center space-x-2">
							<Checkbox
								id="graphics"
								checked={includeGraphics}
								onCheckedChange={(checked) => setIncludeGraphics(checked as boolean)}
							/>
							<Label
								htmlFor="graphics"
								className="text-sm font-normal cursor-pointer leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
							>
								Incluir gráficos e estatísticas visuais
							</Label>
						</div>
					)}

					<div className="pt-4 border-t space-y-4">
						<Button
							onClick={handleGenerate}
							className="w-full"
							size="lg"
							disabled={loading || (needsClientSelection && !selectedClient)}
						>
							<Download className="h-5 w-5 mr-2" />
							Gerar Relatório PDF
						</Button>

						<div className="space-y-2">
							<Label htmlFor="email-recipient">Enviar por Email</Label>
							<div className="flex gap-2">
								<Input
									id="email-recipient"
									type="email"
									value={emailRecipient}
									onChange={(e) => setEmailRecipient(e.target.value)}
									placeholder="destinatario@exemplo.com"
									disabled={sendingEmail}
								/>
								<Button
									onClick={handleSendByEmail}
									disabled={loading || !emailRecipient || sendingEmail || (needsClientSelection && !selectedClient)}
									variant="outline"
								>
									{sendingEmail ? (
										<>Enviando...</>
									) : (
										<>
											<Send className="h-4 w-4 mr-2" />
											Enviar
										</>
									)}
								</Button>
							</div>
							<p className="text-xs text-gray-500">
								O relatório será enviado por email para o destinatário
							</p>
						</div>
					</div>
				</CardContent>
			</Card>

			{/* Lista de Tipos de Relatórios */}
			<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
				{Object.entries(REPORT_CONFIG).map(([type, config]) => {
					const Icon = config.icon;
					const isSelected = selectedReport === type;

					return (
						<Card
							key={type}
							className={`cursor-pointer transition-all ${
								isSelected ? "ring-2 ring-blue-600" : "hover:shadow-md"
							}`}
							onClick={() => setSelectedReport(type as ReportType)}
						>
							<CardHeader>
								<div className="flex items-center gap-3">
									<div className={`p-2 rounded-lg ${config.color} text-white`}>
										<Icon className="h-5 w-5" />
									</div>
									<CardTitle className="text-base">{type}</CardTitle>
								</div>
							</CardHeader>
							<CardContent>
								<p className="text-sm text-gray-600">{config.description}</p>
							</CardContent>
						</Card>
					);
				})}
			</div>
		</div>
	);
}
