import React from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Plus, Search, FileText, Trash2 } from "lucide-react";
import { DemandForm } from "@/components/DemandForm";
import { DemandORM, DemandStatus, DemandPriority } from "@/components/data/orm/orm_demand";
import type { DemandModel } from "@/components/data/orm/orm_demand";
import { ClientORM } from "@/components/data/orm/orm_client";
import type { ClientModel } from "@/components/data/orm/orm_client";

export function DemandList() {
	const [showForm, setShowForm] = React.useState(false);
	const [demands, setDemands] = React.useState<DemandModel[]>([]);
	const [clients, setClients] = React.useState<Map<string, ClientModel>>(new Map());
	const [loading, setLoading] = React.useState(true);
	const [searchTerm, setSearchTerm] = React.useState("");
	const demandORM = React.useMemo(() => DemandORM.getInstance(), []);
	const clientORM = React.useMemo(() => ClientORM.getInstance(), []);

	React.useEffect(() => {
		loadData();
	}, []);

	const loadData = async () => {
		try {
			setLoading(true);
			const [demandsData, clientsData] = await Promise.all([
				demandORM.getAllDemand(),
				clientORM.getAllClient(),
			]);

			const clientMap = new Map(clientsData.map((c: ClientModel) => [c.id, c]));
			setClients(clientMap);
			setDemands(demandsData);
		} catch (error) {
			console.error("Error loading demands:", error);
		} finally {
			setLoading(false);
		}
	};

	const handleDelete = async (id: string) => {
		if (!confirm("Tem certeza que deseja excluir esta demanda? Esta ação não pode ser desfeita.")) return;
		try {
			await demandORM.deleteDemandById(id);
			await loadData();
		} catch (error) {
			console.error("Error deleting demand:", error);
			alert("Erro ao excluir demanda.");
		}
	};

	const filteredDemands = React.useMemo(() => {
		return demands.filter((demand) => {
			const client = clients.get(demand.client_id);
			const clientName = client?.full_name || "";
			const demandNumber = demand.demand_number || "";

			return (
				clientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
				demandNumber.toLowerCase().includes(searchTerm.toLowerCase())
			);
		});
	}, [demands, clients, searchTerm]);

	const getStatusBadge = (status: DemandStatus) => {
		const variants: Record<number, { label: string; className: string }> = {
			[DemandStatus.New]: { label: "Nova", className: "bg-blue-100 text-blue-800" },
			[DemandStatus.InProgress]: { label: "Em Andamento", className: "bg-yellow-100 text-yellow-800" },
			[DemandStatus.Waiting]: { label: "Aguardando", className: "bg-orange-100 text-orange-800" },
			[DemandStatus.Suspended]: { label: "Suspensa", className: "bg-gray-100 text-gray-800" },
			[DemandStatus.Concluded]: { label: "Concluída", className: "bg-green-100 text-green-800" },
			[DemandStatus.Archived]: { label: "Arquivada", className: "bg-slate-100 text-slate-800" },
		};
		const variant = variants[status] || { label: "Desconhecido", className: "bg-gray-100 text-gray-800" };
		return <Badge className={variant.className}>{variant.label}</Badge>;
	};

	const getPriorityBadge = (priority: DemandPriority) => {
		const variants: Record<number, { label: string; className: string }> = {
			[DemandPriority.Low]: { label: "Baixa", className: "bg-gray-100 text-gray-800" },
			[DemandPriority.Medium]: { label: "Média", className: "bg-blue-100 text-blue-800" },
			[DemandPriority.High]: { label: "Alta", className: "bg-orange-100 text-orange-800" },
			[DemandPriority.Critical]: { label: "Crítica", className: "bg-red-100 text-red-800" },
		};
		const variant = variants[priority] || { label: "Desconhecido", className: "bg-gray-100 text-gray-800" };
		return <Badge className={variant.className}>{variant.label}</Badge>;
	};

	if (showForm) {
		return (
			<DemandForm
				onClose={() => {
					setShowForm(false);
					loadData();
				}}
			/>
		);
	}

	return (
		<div className="space-y-6">
			<div className="flex items-center justify-between">
				<div>
					<h2 className="text-3xl font-bold text-gray-900">Demandas</h2>
					<p className="text-sm text-gray-600 mt-1">
						Gerenciar demandas e processos
					</p>
				</div>
				<Button onClick={() => setShowForm(true)} className="gap-2">
					<Plus className="w-4 h-4" />
					Nova Demanda
				</Button>
			</div>

			<Card>
				<CardHeader>
					<div className="flex items-center gap-4">
						<div className="flex-1 relative">
							<Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
							<Input
								placeholder="Buscar por cliente ou número da demanda..."
								value={searchTerm}
								onChange={(e) => setSearchTerm(e.target.value)}
								className="pl-10"
							/>
						</div>
					</div>
				</CardHeader>
				<CardContent>
					{loading ? (
						<div className="text-center py-8 text-gray-500">
							Carregando demandas...
						</div>
					) : filteredDemands.length === 0 ? (
						<div className="text-center py-8">
							<FileText className="w-12 h-12 mx-auto mb-3 text-gray-300" />
							<p className="text-gray-500">
								{searchTerm ? "Nenhuma demanda encontrada" : "Nenhuma demanda cadastrada"}
							</p>
							{!searchTerm && (
								<Button
									onClick={() => setShowForm(true)}
									variant="outline"
									className="mt-4 gap-2"
								>
									<Plus className="w-4 h-4" />
									Cadastrar Primeira Demanda
								</Button>
							)}
						</div>
					) : (
						<div className="space-y-4">
							{filteredDemands.map((demand) => {
								const client = clients.get(demand.client_id);
								return (
									<Card key={demand.id} className="hover:shadow-md transition-shadow">
										<CardContent className="p-4">
											<div className="flex items-start justify-between gap-4">
												<div className="flex-1 space-y-2">
													<div className="flex items-center gap-2">
														<h3 className="font-semibold text-lg">
															{client?.full_name || "Cliente não encontrado"}
														</h3>
														{getStatusBadge(demand.status)}
														{getPriorityBadge(demand.priority)}
													</div>
													{demand.demand_number && (
														<p className="text-sm text-gray-600">
															Número: {demand.demand_number}
														</p>
													)}
													{demand.description && (
														<p className="text-sm text-gray-600 line-clamp-2">
															{demand.description}
														</p>
													)}
													<p className="text-xs text-gray-500">
														Criado em: {new Date(demand.create_time).toLocaleDateString('pt-BR')}
													</p>
												</div>
												<Button
													variant="ghost"
													size="sm"
													onClick={() => handleDelete(demand.id)}
													className="text-red-600 hover:text-red-700 hover:bg-red-50"
												>
													<Trash2 className="w-4 h-4" />
												</Button>
											</div>
										</CardContent>
									</Card>
								);
							})}
						</div>
					)}
				</CardContent>
			</Card>
		</div>
	);
}
