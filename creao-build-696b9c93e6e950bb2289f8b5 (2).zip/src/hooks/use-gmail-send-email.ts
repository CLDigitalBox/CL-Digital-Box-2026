import { useMutation, useQueryClient } from '@tanstack/react-query';
import { callMCPTool, type MCPToolResponse } from '@/sdk/core/mcp-client';

/**
 * Input parameters for sending an email via Gmail
 */
export interface GmailSendEmailInput {
  /** Primary recipient's email address */
  recipient_email: string;
  /** Email content (plain text or HTML); if HTML, `is_html` must be `true` */
  body: string;
  /** Subject line of the email */
  subject?: string | null;
  /** Set to `true` if the email body contains HTML tags */
  is_html?: boolean;
  /** Carbon Copy (CC) recipients' email addresses */
  cc?: string[];
  /** Blind Carbon Copy (BCC) recipients' email addresses */
  bcc?: string[];
  /** Additional 'To' recipients' email addresses (not Cc or Bcc) */
  extra_recipients?: string[];
  /** File to attach; ensure `s3key`, `mimetype`, and `name` are set if provided. Omit or set to null for no attachment */
  attachment?: string | null;
  /** User's email address; the literal 'me' refers to the authenticated user */
  user_id?: string;
}

/**
 * Response data from Gmail API after sending an email
 */
export interface GmailSendEmailResponse {
  /** Gmail API response, typically including the sent message ID and threadId */
  response_data: {
    /** Sent message ID */
    id?: string;
    /** Thread ID */
    threadId?: string;
    /** Label IDs */
    labelIds?: string[];
    [key: string]: unknown;
  };
}

/**
 * Wrapper response from the MCP tool execution
 */
export interface GmailSendEmailOutputData {
  /** Data from the action execution */
  data: GmailSendEmailResponse;
  /** Error if any occurred during the execution of the action */
  error: string | null;
  /** Whether or not the action execution was successful or not */
  successful: boolean;
}

/**
 * React hook for sending emails via Gmail using the GMAIL_SEND_EMAIL MCP tool.
 *
 * This is a mutation hook that sends emails through Gmail's API with support for:
 * - HTML and plain text email bodies
 * - CC and BCC recipients
 * - Multiple recipients
 * - File attachments
 *
 * @returns TanStack Query mutation hook for sending emails
 *
 * @example
 * const sendEmail = useGmailSendEmail();
 *
 * sendEmail.mutate({
 *   recipient_email: 'recipient@example.com',
 *   subject: 'Project Update',
 *   body: '<h1>Status Report</h1><p>Project is on track.</p>',
 *   is_html: true,
 *   cc: ['manager@example.com']
 * });
 */
export function useGmailSendEmail() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (params: GmailSendEmailInput) => {
      if (!params) {
        throw new Error('Parameters are required for sending email via Gmail');
      }

      if (!params.recipient_email) {
        throw new Error('recipient_email is required');
      }

      if (!params.body) {
        throw new Error('body is required');
      }

      // CRITICAL: Use MCPToolResponse and parse JSON response
      const mcpResponse = await callMCPTool<MCPToolResponse, GmailSendEmailInput>(
        '686de5276fd1cae1afbb55be',
        'GMAIL_SEND_EMAIL',
        params
      );

      if (!mcpResponse.content?.[0]?.text) {
        throw new Error('Invalid MCP response format: missing content[0].text');
      }

      try {
        const toolData: GmailSendEmailOutputData = JSON.parse(mcpResponse.content[0].text);

        // Check if the Gmail API execution was successful
        if (!toolData.successful) {
          throw new Error(toolData.error || 'Failed to send email via Gmail');
        }

        return toolData;
      } catch (parseError) {
        if (parseError instanceof SyntaxError) {
          throw new Error(`Failed to parse MCP response JSON: ${parseError.message}`);
        }
        throw parseError;
      }
    },
    onSuccess: () => {
      // Invalidate related queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['gmail-emails'] });
      queryClient.invalidateQueries({ queryKey: ['gmail-threads'] });
    },
    retry: 2,
    retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),
  });
}
